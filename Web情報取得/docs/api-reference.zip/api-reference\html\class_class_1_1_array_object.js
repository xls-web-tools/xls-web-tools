var class_class_1_1_array_object =
[
    [ "ReDimArray", "class_class_1_1_array_object.html#aff3bc6adda4c12cebb17493f4840b136", null ],
    [ "Update", "class_class_1_1_array_object.html#a28ddf3ca63b3127f26b6fa93847c2866", null ],
    [ "LowerBound", "class_class_1_1_array_object.html#a0fcf4e40134c9445828360aef994fa96", null ],
    [ "UpperBound", "class_class_1_1_array_object.html#a8899e0a1ba6ac8d55e11c20e8f210925", null ],
    [ "this[Long ItemIndex]", "class_class_1_1_array_object.html#a31ec5f3832514f7332a55338fffe5010", null ]
];