var interface_class_1_1_i_tool_settings =
[
    [ "WebDriverPath", "interface_class_1_1_i_tool_settings.html#ada57808b6cdec95c7a75a28adf059144", null ],
    [ "WebDriverPort", "interface_class_1_1_i_tool_settings.html#a08b3ceab0a10fa1f101651a53ff275a9", null ],
    [ "BrowserProfilePath", "interface_class_1_1_i_tool_settings.html#a140b0ce22623276bfced84bd87faaf8d", null ],
    [ "Headless", "interface_class_1_1_i_tool_settings.html#a0c377308839693dca720e3a623c9bf1e", null ],
    [ "StartUrl", "interface_class_1_1_i_tool_settings.html#a731329223b6065cf09171703c6b9eef6", null ],
    [ "OutputSheetName", "interface_class_1_1_i_tool_settings.html#a3e67e1d30e2a44d7c8198d5637365c96", null ],
    [ "AuthenticatedStartSelector", "interface_class_1_1_i_tool_settings.html#a197ecf049ed1dbb2cbecb7f8bfe14a9f", null ],
    [ "ListPageSelector", "interface_class_1_1_i_tool_settings.html#a9b16e07ba475155ea09a5060fdf3d1a1", null ],
    [ "ListTransitionOperationName", "interface_class_1_1_i_tool_settings.html#a0e7d3d3778bc0e4133f77c2a7dde489c", null ],
    [ "ExistingRowMode", "interface_class_1_1_i_tool_settings.html#a684e10258afdd34fbde9431d1e360cf3", null ],
    [ "TimeoutSeconds", "interface_class_1_1_i_tool_settings.html#ac844c256d9386d4a7075848fb829ea69", null ],
    [ "TransitionOperations", "interface_class_1_1_i_tool_settings.html#a1e1ce256074ba46929366713aa29da61", null ],
    [ "DetailColumnDefinitions", "interface_class_1_1_i_tool_settings.html#ab822282242048aeb5d3f7e42fd1f592f", null ]
];