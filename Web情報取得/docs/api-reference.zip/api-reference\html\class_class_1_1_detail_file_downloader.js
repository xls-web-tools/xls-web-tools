var class_class_1_1_detail_file_downloader =
[
    [ "Initialize", "class_class_1_1_detail_file_downloader.html#a9077bc2051cd52ecfd9c8313b7365aec", null ],
    [ "DownloadForDetail", "class_class_1_1_detail_file_downloader.html#a3b38d0fa1269ae3e7e7372891bf47edc", null ]
];