var class_class_1_1_web_collection_run_lifecycle =
[
    [ "Initialize", "class_class_1_1_web_collection_run_lifecycle.html#ad665e8132674677f21157ebfc85e82d2", null ],
    [ "Run", "class_class_1_1_web_collection_run_lifecycle.html#ae5e996b07e3fda5226b66daf66c48957", null ]
];