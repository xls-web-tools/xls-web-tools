var class_class_1_1_worksheet_virtual_table =
[
    [ "Initialize", "class_class_1_1_worksheet_virtual_table.html#a324f7934b140aa34b718ad3085c725fe", null ],
    [ "InitializeFromRangeBounds", "class_class_1_1_worksheet_virtual_table.html#ad8c64f86dc620138d8e125e00653ced7", null ],
    [ "GetRow", "class_class_1_1_worksheet_virtual_table.html#a8e27a035721176a904e29c187bb13079", null ],
    [ "GetEnumerator", "class_class_1_1_worksheet_virtual_table.html#aec5ae5e702028c12a879f48a1f32119b", null ],
    [ "Count", "class_class_1_1_worksheet_virtual_table.html#a37f4d421700ca7737c6ef6a147ea37c8", null ],
    [ "RowCount", "class_class_1_1_worksheet_virtual_table.html#a0291aa022f9c0f2cb5afb1ccf46116dc", null ],
    [ "Headers", "class_class_1_1_worksheet_virtual_table.html#aedb776ff3ce895da61fa7cf367e808fe", null ],
    [ "NewEnum", "class_class_1_1_worksheet_virtual_table.html#a2efac1f9086a4793dd2ab306576e8c6d", null ],
    [ "this[Long ItemIndex]", "class_class_1_1_worksheet_virtual_table.html#ae3c12f5fc21fd5399d32e62392f9ae21", null ]
];