var class_class_1_1_web_driver_session_client =
[
    [ "Initialize", "class_class_1_1_web_driver_session_client.html#a2fccf3ba7d578d2dbcf4474ae26a8f5a", null ],
    [ "CreateSession", "class_class_1_1_web_driver_session_client.html#a6a6e8315e8bedbfc5701bf9b0b48dcb8", null ],
    [ "NavigateToStartUrl", "class_class_1_1_web_driver_session_client.html#a5e4f7f21712eae8ed0ad9a279d3f7b44", null ],
    [ "WaitForSelector", "class_class_1_1_web_driver_session_client.html#a024ea62aa01c803f0ac97d9b080268a3", null ],
    [ "CountElements", "class_class_1_1_web_driver_session_client.html#aad623af734e87ad9efb2229a286828bd", null ],
    [ "TryNavigateDownloadLink", "class_class_1_1_web_driver_session_client.html#a09314e2784f4dee6cb81dbb933bfc8f0", null ],
    [ "ClickElement", "class_class_1_1_web_driver_session_client.html#a1f8da3e6658d3d6b697a06be554bc514", null ],
    [ "ReadElementText", "class_class_1_1_web_driver_session_client.html#aa365db0c5cb47cf3e33ccebdb76f87dd", null ],
    [ "ReadDetailColumnValues", "class_class_1_1_web_driver_session_client.html#a1b6c825154166c490f9b948e37ea49b0", null ],
    [ "RunTransitionOperationChain", "class_class_1_1_web_driver_session_client.html#a2e32198c3dddb8537887b09d8cb26f4f", null ],
    [ "RunTransitionOperation", "class_class_1_1_web_driver_session_client.html#aa489f0d7359a1ada79534343fc1c013b", null ],
    [ "QuitSession", "class_class_1_1_web_driver_session_client.html#abe58d11d7920228a29c6369df6b9b6e5", null ],
    [ "SessionId", "class_class_1_1_web_driver_session_client.html#a22709ecb9cbccc633d5e8d6279f37ba3", null ],
    [ "DownloadDirectoryPath", "class_class_1_1_web_driver_session_client.html#ac39b62d3b21c0e7e46206bc4cc4cd914", null ]
];