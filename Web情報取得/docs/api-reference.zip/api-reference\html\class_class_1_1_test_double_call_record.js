var class_class_1_1_test_double_call_record =
[
    [ "StoreArguments", "class_class_1_1_test_double_call_record.html#a0a5303efeee75a7c785908342dd2da12", null ],
    [ "GetArgument", "class_class_1_1_test_double_call_record.html#adf50f15f6a6d3d604a6db2bae8e382b4", null ],
    [ "MethodName", "class_class_1_1_test_double_call_record.html#a2838b69e656be04aad664fa8c569ff32", null ],
    [ "CallIndex", "class_class_1_1_test_double_call_record.html#a26c92d4a07587584f3036ced9c4f4205", null ],
    [ "ObjectKeyMode", "class_class_1_1_test_double_call_record.html#acb21c7651a7545f611415fadd561b960", null ],
    [ "ArgumentCount", "class_class_1_1_test_double_call_record.html#adbf0b175692b5ac622b528a11daa4b00", null ]
];