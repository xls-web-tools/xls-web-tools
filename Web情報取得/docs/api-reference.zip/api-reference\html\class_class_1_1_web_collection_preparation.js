var class_class_1_1_web_collection_preparation =
[
    [ "Initialize", "class_class_1_1_web_collection_preparation.html#abd0cfdab2ef77869d7a58e8129ad23c1", null ],
    [ "Run", "class_class_1_1_web_collection_preparation.html#a56791be8751f940ac71a7f5edb6ab9c8", null ],
    [ "ClearProgress", "class_class_1_1_web_collection_preparation.html#af9aa0c1538c6c8c4a87f05a081000a87", null ]
];