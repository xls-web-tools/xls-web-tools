var class_class_1_1_tool_settings_test_double =
[
    [ "WebDriverPath", "class_class_1_1_tool_settings_test_double.html#a5c9882d897c36b864b8e22fef8915da2", null ],
    [ "WebDriverPort", "class_class_1_1_tool_settings_test_double.html#af66e6cfd43e78bb2300b07cb8f38bc00", null ],
    [ "BrowserProfilePath", "class_class_1_1_tool_settings_test_double.html#a5af79c0a5a20e4fe3268c8a1a2278123", null ],
    [ "Headless", "class_class_1_1_tool_settings_test_double.html#ac1d5565f8e2e2310c3d645833f7279ef", null ],
    [ "StartUrl", "class_class_1_1_tool_settings_test_double.html#a759fff56cca4b49ffcc4bfa9a6de6c09", null ],
    [ "OutputSheetName", "class_class_1_1_tool_settings_test_double.html#a53669aca82a3950d5961cfdd8ee43a86", null ],
    [ "AuthenticatedStartSelector", "class_class_1_1_tool_settings_test_double.html#a14bb1b160a279673fb2ff5489f00960e", null ],
    [ "ListPageSelector", "class_class_1_1_tool_settings_test_double.html#a1815ce3f61a2117cb686c21e156c9f09", null ],
    [ "ListTransitionOperationName", "class_class_1_1_tool_settings_test_double.html#aba56f02197a2d4bea45a77db5db1a94e", null ],
    [ "ExistingRowMode", "class_class_1_1_tool_settings_test_double.html#a65b74a94032b523510b90178bde27368", null ],
    [ "TimeoutSeconds", "class_class_1_1_tool_settings_test_double.html#a83c3945f5c383ced850889e745cd7a5d", null ],
    [ "TransitionOperations", "class_class_1_1_tool_settings_test_double.html#ad9cc0b86bf88d50ebea520d659135c24", null ],
    [ "DetailColumnDefinitions", "class_class_1_1_tool_settings_test_double.html#a0a65598d56ecd454d92bdce374537e0e", null ]
];