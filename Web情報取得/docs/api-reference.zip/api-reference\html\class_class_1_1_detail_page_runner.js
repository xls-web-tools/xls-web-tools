var class_class_1_1_detail_page_runner =
[
    [ "Initialize", "class_class_1_1_detail_page_runner.html#ae88d029a696428e3cc8013be2af4505e", null ],
    [ "Run", "class_class_1_1_detail_page_runner.html#ad83197a26a17ceae05dd0bafd2962c41", null ]
];