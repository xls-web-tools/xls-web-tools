var class_class_1_1_web_collection_run_body_test_double =
[
    [ "RunAfterPreparation", "class_class_1_1_web_collection_run_body_test_double.html#ac2430e0638660530ede1b9289487eea6", null ],
    [ "ClearProgressAfterError", "class_class_1_1_web_collection_run_body_test_double.html#ae318779f85e6e7efbdeef8c13b46910c", null ],
    [ "Store", "class_class_1_1_web_collection_run_body_test_double.html#a404697628e6c5b07fa8a518fcebc9ab9", null ]
];