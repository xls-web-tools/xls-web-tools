var class_class_1_1_transition_operation_resolver =
[
    [ "Initialize", "class_class_1_1_transition_operation_resolver.html#aaacf5534d8a7aca93ae4037024d45a32", null ],
    [ "ResolveListTransitionOperation", "class_class_1_1_transition_operation_resolver.html#a6f86ef99d221c60bef9371c5f6540851", null ],
    [ "ResolveDetailTransitionOperation", "class_class_1_1_transition_operation_resolver.html#a9be6063c24d4f3d5083253969d73749c", null ],
    [ "ResolveReturnToListOperation", "class_class_1_1_transition_operation_resolver.html#a378468cb4ea04ceba5c606b1828170a4", null ],
    [ "ResolveNextPageOperation", "class_class_1_1_transition_operation_resolver.html#a12dadc8425cc3523691d2448b7653316", null ],
    [ "HasDetailTransitionOperation", "class_class_1_1_transition_operation_resolver.html#af99b93ca7484f5a20d69de900b09abe6", null ],
    [ "HasReturnToListOperation", "class_class_1_1_transition_operation_resolver.html#a810393212d53896897659b75b6ffe763", null ]
];