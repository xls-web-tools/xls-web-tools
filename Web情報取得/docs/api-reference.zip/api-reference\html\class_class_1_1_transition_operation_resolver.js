var class_class_1_1_transition_operation_resolver =
[
    [ "Initialize", "class_class_1_1_transition_operation_resolver.html#aaacf5534d8a7aca93ae4037024d45a32", null ],
    [ "ResolveListTransitionOperation", "class_class_1_1_transition_operation_resolver.html#a5fd1cb558e32026f0ea49e2b93e0e1c5", null ],
    [ "ResolveDetailTransitionOperation", "class_class_1_1_transition_operation_resolver.html#a006e46d21d12c50c545d563c78fe905d", null ],
    [ "ResolveReturnToListOperation", "class_class_1_1_transition_operation_resolver.html#a9a775795d9564a0ee4688ad8231203ef", null ],
    [ "ResolveNextPageOperation", "class_class_1_1_transition_operation_resolver.html#a0b042889b942b481ec9bae205dee8159", null ]
];