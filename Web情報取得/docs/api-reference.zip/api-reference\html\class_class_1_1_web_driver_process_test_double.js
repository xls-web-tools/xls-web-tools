var class_class_1_1_web_driver_process_test_double =
[
    [ "Start", "class_class_1_1_web_driver_process_test_double.html#a0049934242d50ab03df2fa8e989daa64", null ],
    [ "StopProcess", "class_class_1_1_web_driver_process_test_double.html#a405e3ccbfb773aa2065d077c241f088a", null ],
    [ "Store", "class_class_1_1_web_driver_process_test_double.html#a6ed24b1170fe33f6a3fbbed87b12fdf6", null ],
    [ "IsRunning", "class_class_1_1_web_driver_process_test_double.html#ae2d4bff5a3fdd385c920a2f562f93bd1", null ]
];