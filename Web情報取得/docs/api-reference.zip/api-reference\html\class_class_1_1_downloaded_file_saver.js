var class_class_1_1_downloaded_file_saver =
[
    [ "Initialize", "class_class_1_1_downloaded_file_saver.html#a8783658f81267cafaa631f60c35da391", null ],
    [ "SaveDownloadedFile", "class_class_1_1_downloaded_file_saver.html#a182bf5b9cd8bb044437fb04a8e548023", null ],
    [ "LastErrorDescription", "class_class_1_1_downloaded_file_saver.html#adc1a427350d1cb3da87702380487b020", null ]
];