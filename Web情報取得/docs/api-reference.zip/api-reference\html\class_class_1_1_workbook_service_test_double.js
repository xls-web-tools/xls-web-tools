var class_class_1_1_workbook_service_test_double =
[
    [ "GetThisWorkbookName", "class_class_1_1_workbook_service_test_double.html#a973057b97f62542ed91ccbf25b8ace9b", null ],
    [ "GetThisWorkbookDirectoryPath", "class_class_1_1_workbook_service_test_double.html#a91ccafd3c5a840f89077ab07a6016cc7", null ],
    [ "WorkbookExists", "class_class_1_1_workbook_service_test_double.html#a93e879876f716f013688e1a8ab1f24c5", null ],
    [ "GetAllWorkbooks", "class_class_1_1_workbook_service_test_double.html#ac71f064fba12600d2c0d9e66eadc64d7", null ],
    [ "GetOtherWorkbooks", "class_class_1_1_workbook_service_test_double.html#a6ddd455efdd5eb66c81032488b626aae", null ],
    [ "WorksheetExists", "class_class_1_1_workbook_service_test_double.html#a81f3acc4bfc4bd4c8b6a34764ec86d87", null ],
    [ "GetAllWorksheets", "class_class_1_1_workbook_service_test_double.html#adee86a31491fe4bd3f17c358e4ce3122", null ],
    [ "GetOtherWorksheets", "class_class_1_1_workbook_service_test_double.html#a488d1e9a80b47ca40e3489afbbedc140", null ],
    [ "OpenWorkbook", "class_class_1_1_workbook_service_test_double.html#a4bfc1c71a00da4a17e0c6fe8c21f6a0f", null ],
    [ "SaveWorkbook", "class_class_1_1_workbook_service_test_double.html#aa9c9ca0ae17b21b230bccdec6cd37019", null ],
    [ "IsSaved", "class_class_1_1_workbook_service_test_double.html#a32597f36135fd91d36773b71fec452f1", null ],
    [ "HasPath", "class_class_1_1_workbook_service_test_double.html#ada988d8b57d78f525e09048be24bf8e9", null ],
    [ "CloseWorkbook", "class_class_1_1_workbook_service_test_double.html#a0ba7b4b9364a9fa2e1bf0db81d19f183", null ],
    [ "Find", "class_class_1_1_workbook_service_test_double.html#aff3d2f9a6263df2dc7312a7659da46db", null ],
    [ "AddWorksheet", "class_class_1_1_workbook_service_test_double.html#a85ba3cdf989ea0e70cf3138877f9c6ae", null ],
    [ "RemoveWorksheet", "class_class_1_1_workbook_service_test_double.html#afd0efeabd48aa50ba03adcf3982e3ea9", null ],
    [ "CopyWorksheet", "class_class_1_1_workbook_service_test_double.html#a327b28e0d254d20751ebcd12f3a5deda", null ],
    [ "ActivateWorksheet", "class_class_1_1_workbook_service_test_double.html#a8635aee3223e2d5330c4944119a825bc", null ],
    [ "RemoveVBComponents", "class_class_1_1_workbook_service_test_double.html#ad070ac638522503aceee75e70422f0aa", null ],
    [ "Store", "class_class_1_1_workbook_service_test_double.html#ae5c647360e7d0a8c421194fba2930e94", null ]
];