var interface_class_1_1_i_web_collection_run_body =
[
    [ "RunAfterPreparation", "interface_class_1_1_i_web_collection_run_body.html#a45788e30c2cbb7a5393a467f32029704", null ],
    [ "ClearProgressAfterError", "interface_class_1_1_i_web_collection_run_body.html#a606f063e6d99a41665a804fb0a083ecf", null ]
];