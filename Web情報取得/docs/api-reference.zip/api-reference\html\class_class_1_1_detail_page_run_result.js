var class_class_1_1_detail_page_run_result =
[
    [ "Initialize", "class_class_1_1_detail_page_run_result.html#ac2ce15297f5d530ac428fb2535c5f43c", null ],
    [ "TargetId", "class_class_1_1_detail_page_run_result.html#a80a6ba6f1f4a825b3c004df1f3a0a3ef", null ],
    [ "Status", "class_class_1_1_detail_page_run_result.html#a42e7fa14f7d86f199eed2c80401ed5f3", null ],
    [ "ErrorDescription", "class_class_1_1_detail_page_run_result.html#a06b17da7360d829c805169d250b5bcd4", null ],
    [ "DetailValues", "class_class_1_1_detail_page_run_result.html#a077916b21fa3c4eb9f39d7bc001c365c", null ],
    [ "DownloadStatus", "class_class_1_1_detail_page_run_result.html#a12cf12c97a57d651d3ada99f914a54e0", null ],
    [ "IsOutputExcluded", "class_class_1_1_detail_page_run_result.html#a8d937784c4620435ec37ffaf6b6a3b3c", null ]
];