var class_class_1_1_tool_settings =
[
    [ "WebDriverPath", "class_class_1_1_tool_settings.html#a2827a7d228e160713e0ebc5df7aaf4a0", null ],
    [ "WebDriverPort", "class_class_1_1_tool_settings.html#af9a1e690c3dd43ae95935c20fffdcb90", null ],
    [ "BrowserProfilePath", "class_class_1_1_tool_settings.html#ac41ab4fd34db52b0b7c716c6f37cf50a", null ],
    [ "Headless", "class_class_1_1_tool_settings.html#ab41040b30476f47239c231ff995ad6f5", null ],
    [ "StartUrl", "class_class_1_1_tool_settings.html#a433b292c6d98cf88394e0a1ad3a53055", null ],
    [ "OutputSheetName", "class_class_1_1_tool_settings.html#a690f7162b8a381e7016378dee1d4320f", null ],
    [ "AuthenticatedStartSelector", "class_class_1_1_tool_settings.html#ab93df5e3b11c211820f2e972849cba08", null ],
    [ "ListPageSelector", "class_class_1_1_tool_settings.html#ab7d44e99c66d0481328f7be8d326e159", null ],
    [ "ListTransitionOperationName", "class_class_1_1_tool_settings.html#aaf333533568203ca2f10fc63c1f6e597", null ],
    [ "ExistingRowMode", "class_class_1_1_tool_settings.html#acaad8ce27aad654badc0e32fc0161977", null ],
    [ "TimeoutSeconds", "class_class_1_1_tool_settings.html#a4dc41bfa0b35b1d8596c79e65b153f8c", null ],
    [ "TransitionOperations", "class_class_1_1_tool_settings.html#a0aa55e21f543f75a6908877209bf78f5", null ],
    [ "DetailColumnDefinitions", "class_class_1_1_tool_settings.html#ac3e57e04ce31e6e674f6ff178f9c0e7e", null ]
];