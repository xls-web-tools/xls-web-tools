var class_class_1_1_workbook_service =
[
    [ "GetThisWorkbookName", "class_class_1_1_workbook_service.html#a97d71053c8337d2f50277e80b9680ea7", null ],
    [ "GetThisWorkbookDirectoryPath", "class_class_1_1_workbook_service.html#ae3cc75eaffc1d0bcb353a98d096c9d90", null ],
    [ "WorkbookExists", "class_class_1_1_workbook_service.html#ac78fdb16883a7b2b1b675504c1befe6d", null ],
    [ "GetAllWorkbooks", "class_class_1_1_workbook_service.html#aa9271066875d8c93b862cbf28bec7053", null ],
    [ "GetOtherWorkbooks", "class_class_1_1_workbook_service.html#a751d9d58510de219dec28d18b28cc4b7", null ],
    [ "WorksheetExists", "class_class_1_1_workbook_service.html#ae073074e7369aa5f1291c64f39473afa", null ],
    [ "GetAllWorksheets", "class_class_1_1_workbook_service.html#ae57cd0ba7816f4b32fe183d1319ed393", null ],
    [ "GetOtherWorksheets", "class_class_1_1_workbook_service.html#af4b9fd4e55e1c5ead8f83f3b15830a46", null ],
    [ "OpenWorkbook", "class_class_1_1_workbook_service.html#a1fa644597aa2d2d743923096bd77177f", null ],
    [ "SaveWorkbook", "class_class_1_1_workbook_service.html#a2b312842d92ac74bf468b0444c87b042", null ],
    [ "IsSaved", "class_class_1_1_workbook_service.html#a8c75ec66c424dec5e75409f7e8478ca9", null ],
    [ "HasPath", "class_class_1_1_workbook_service.html#a76c1dd15587dbfd2c9df715ec600a4ee", null ],
    [ "CloseWorkbook", "class_class_1_1_workbook_service.html#aaedd15100ba4047cb4512596692a4831", null ],
    [ "Find", "class_class_1_1_workbook_service.html#a7edecba800f89a4fa723efad83f2030c", null ],
    [ "AddWorksheet", "class_class_1_1_workbook_service.html#a37e40e830d0da6015c0efdae48f6ef09", null ],
    [ "RemoveWorksheet", "class_class_1_1_workbook_service.html#ac35126627288a2b2ce418e1650524861", null ],
    [ "CopyWorksheet", "class_class_1_1_workbook_service.html#a54520374639199145d76d442a9f83bd1", null ],
    [ "RemoveVBComponents", "class_class_1_1_workbook_service.html#ad27a932905d32d9e7b43fd15c861a852", null ],
    [ "ActivateWorksheet", "class_class_1_1_workbook_service.html#a96718d31920fff27e0ad743b66d7d819", null ]
];