var class_class_1_1_browser_profile_prompt_test_double =
[
    [ "ConfirmCreateDirectory", "class_class_1_1_browser_profile_prompt_test_double.html#a5f7ae32025021c912ff22f2dd9781741", null ],
    [ "Store", "class_class_1_1_browser_profile_prompt_test_double.html#ae179072a9fbbc3febaa0d26869b64cd8", null ]
];