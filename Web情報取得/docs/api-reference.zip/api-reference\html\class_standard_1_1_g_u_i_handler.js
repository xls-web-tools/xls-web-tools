var class_standard_1_1_g_u_i_handler =
[
    [ "RunDiagnostic_Click", "class_standard_1_1_g_u_i_handler.html#a0f7df45e4f5fb141d6dae2924476fe81", null ],
    [ "Collect_Click", "class_standard_1_1_g_u_i_handler.html#a4585c2b863cdea58269ed411bcbc1df8", null ]
];