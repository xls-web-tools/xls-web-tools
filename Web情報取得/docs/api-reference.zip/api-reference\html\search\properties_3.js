var searchData=
[
  ['defaultobjectkeymode_0',['DefaultObjectKeyMode',['../class_class_1_1_test_double_behavior_store.html#ad8d7ba156a84352f3b6ace3a2442ea6a',1,'Class::TestDoubleBehaviorStore']]],
  ['descending_1',['Descending',['../class_class_1_1_enumerator.html#ab00a87d1421133037e235f0f9f5c5356',1,'Class.Enumerator.Descending'],['../interface_class_1_1_i_enumerator.html#a2a893ead27dc24ae5b8c1b9d0da99ff4',1,'Class.IEnumerator.Descending'],['../class_class_1_1_worksheet_range_bounds_enumerator.html#a66796e4582aa396b0d70b58ec1658d2b',1,'Class.WorksheetRangeBoundsEnumerator.Descending']]],
  ['detailcolumndefinitions_2',['DetailColumnDefinitions',['../interface_class_1_1_i_tool_settings.html#ab822282242048aeb5d3f7e42fd1f592f',1,'Class.IToolSettings.DetailColumnDefinitions'],['../class_class_1_1_tool_settings.html#ac3e57e04ce31e6e674f6ff178f9c0e7e',1,'Class.ToolSettings.DetailColumnDefinitions'],['../class_class_1_1_tool_settings_test_double.html#a0a65598d56ecd454d92bdce374537e0e',1,'Class.ToolSettingsTestDouble.DetailColumnDefinitions']]]
];
