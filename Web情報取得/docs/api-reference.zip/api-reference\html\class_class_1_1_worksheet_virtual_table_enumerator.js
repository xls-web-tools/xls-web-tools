var class_class_1_1_worksheet_virtual_table_enumerator =
[
    [ "Initialize", "class_class_1_1_worksheet_virtual_table_enumerator.html#aeaa4a7e9fc6952c83b1cb567f2d1c9ec", null ],
    [ "MoveNext", "class_class_1_1_worksheet_virtual_table_enumerator.html#a816fbf9ba7a953dbecab098c0f68956b", null ],
    [ "Reset", "class_class_1_1_worksheet_virtual_table_enumerator.html#a9af19535611a95418cb5a02af4e25de6", null ],
    [ "SkipTo", "class_class_1_1_worksheet_virtual_table_enumerator.html#a92700915c2ebb62f8400adaf5a24a369", null ],
    [ "Remove", "class_class_1_1_worksheet_virtual_table_enumerator.html#a5004a03a12080711bebd5de826ad1773", null ],
    [ "Update", "class_class_1_1_worksheet_virtual_table_enumerator.html#a1ae9e1871dfbe09776ff0fdd37056818", null ],
    [ "Descending", "class_class_1_1_worksheet_virtual_table_enumerator.html#a4938589d7ecf0d425dcf2bb3429563b6", null ],
    [ "IsReadOnly", "class_class_1_1_worksheet_virtual_table_enumerator.html#a5b7dd93caa1d52083f2fecb3396a1fbc", null ],
    [ "Current", "class_class_1_1_worksheet_virtual_table_enumerator.html#a0272ee326e0428df0bc19d0e7405005e", null ],
    [ "Index", "class_class_1_1_worksheet_virtual_table_enumerator.html#abe4e446e5afe2e08e902eaa794621f94", null ],
    [ "Target", "class_class_1_1_worksheet_virtual_table_enumerator.html#a267ba5b1a58af17007c8a836dc2640f6", null ]
];