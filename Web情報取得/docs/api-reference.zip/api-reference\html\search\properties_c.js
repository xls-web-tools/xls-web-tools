var searchData=
[
  ['pagecount_0',['PageCount',['../class_class_1_1_web_collection_runner.html#a00c78e4df568781b8b956b4c31035acd',1,'Class::WebCollectionRunner']]],
  ['processedvalue_1',['ProcessedValue',['../class_class_1_1_progress_status.html#aeb97dc78551fa461c3da5344e4af8193',1,'Class::ProgressStatus']]]
];
