var class_class_1_1_detail_column_definition =
[
    [ "Initialize", "class_class_1_1_detail_column_definition.html#a3294455ddf07d0dc38242a89239dbe12", null ],
    [ "OutputColumnName", "class_class_1_1_detail_column_definition.html#a0fc9509e8640dadfb0cfb406b1b8286f", null ],
    [ "Selector", "class_class_1_1_detail_column_definition.html#a5065d3fc3ce3a6ae74cbefe7a1aa3792", null ],
    [ "ExtractType", "class_class_1_1_detail_column_definition.html#a8b00cb3814c7bf16c069aaaf010efcc4", null ],
    [ "AttributeName", "class_class_1_1_detail_column_definition.html#a0ea6ca9fe993f18f84f4fd088cbb3025", null ],
    [ "IsRequired", "class_class_1_1_detail_column_definition.html#af8b6b6f1541a2a120977ed0b70cb180a", null ],
    [ "BlankMode", "class_class_1_1_detail_column_definition.html#a41bb82a58d37de40084862e53a3ef6bc", null ]
];