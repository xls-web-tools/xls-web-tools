var searchData=
[
  ['newenum_0',['NewEnum',['../class_class_1_1_object_list.html#a9785147a008edbb847afba22b48717ce',1,'Class.ObjectList.NewEnum'],['../class_class_1_1_object_set.html#aa536ef43dc9ce4af56507285b33051f7',1,'Class.ObjectSet.NewEnum'],['../class_class_1_1_worksheet_range_bounds.html#a75eccecfe65666890aa1c52ae69cc4fa',1,'Class.WorksheetRangeBounds.NewEnum']]]
];
