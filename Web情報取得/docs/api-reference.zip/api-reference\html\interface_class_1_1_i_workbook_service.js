var interface_class_1_1_i_workbook_service =
[
    [ "GetThisWorkbookName", "interface_class_1_1_i_workbook_service.html#a3debb6d47f004d7515f5e9a87e377e6d", null ],
    [ "GetThisWorkbookDirectoryPath", "interface_class_1_1_i_workbook_service.html#ab9330bae3a821295fd7ff861fbfc4112", null ],
    [ "WorkbookExists", "interface_class_1_1_i_workbook_service.html#aeeb63da11bfc66f848ee264f6f9828e6", null ],
    [ "GetAllWorkbooks", "interface_class_1_1_i_workbook_service.html#a6a76856a13e559835ae047b24160ea40", null ],
    [ "GetOtherWorkbooks", "interface_class_1_1_i_workbook_service.html#ac474316bc66cf412cd45cb7ba590b88d", null ],
    [ "WorksheetExists", "interface_class_1_1_i_workbook_service.html#a539107ceb2fb3d533a7534bd15257564", null ],
    [ "GetAllWorksheets", "interface_class_1_1_i_workbook_service.html#a7f3b9a3bd0fdcf0cf9f739bad184d2ce", null ],
    [ "GetOtherWorksheets", "interface_class_1_1_i_workbook_service.html#a5ab53e2cc6b4221857e662360880ab12", null ],
    [ "OpenWorkbook", "interface_class_1_1_i_workbook_service.html#a148bcc457ec218a9103d0894185e8f43", null ],
    [ "SaveWorkbook", "interface_class_1_1_i_workbook_service.html#ad6caad48ec9f45a6a44aea6ed483b6f6", null ],
    [ "IsSaved", "interface_class_1_1_i_workbook_service.html#a465002b028ce5effb14446df378b080e", null ],
    [ "HasPath", "interface_class_1_1_i_workbook_service.html#a94a6ab9c5d2bd9a852dabfb6d610b408", null ],
    [ "CloseWorkbook", "interface_class_1_1_i_workbook_service.html#a678dbd3a62f419597f136b0fc0f9e273", null ],
    [ "Find", "interface_class_1_1_i_workbook_service.html#a1f03fa941a8e7d7162011d0b8e86e4ba", null ],
    [ "AddWorksheet", "interface_class_1_1_i_workbook_service.html#a439517204f3fb264dad5d0b9ac9a9d4f", null ],
    [ "RemoveWorksheet", "interface_class_1_1_i_workbook_service.html#ad187ba68c6cfd9d1c828ae4ec1e0e4c2", null ],
    [ "CopyWorksheet", "interface_class_1_1_i_workbook_service.html#a0323d94fea2a8f53bb2e533fd7dfc030", null ],
    [ "ActivateWorksheet", "interface_class_1_1_i_workbook_service.html#a1687a6b8a4f13298c249d48ba1e9accd", null ],
    [ "RemoveVBComponents", "interface_class_1_1_i_workbook_service.html#abd383f541b71a3b9f76381f11076206c", null ]
];