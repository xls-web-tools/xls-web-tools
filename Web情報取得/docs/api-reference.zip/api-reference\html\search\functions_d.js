var searchData=
[
  ['openworkbook_0',['OpenWorkbook',['../interface_class_1_1_i_workbook_service.html#a148bcc457ec218a9103d0894185e8f43',1,'Class.IWorkbookService.OpenWorkbook()'],['../class_class_1_1_workbook_service.html#a1fa644597aa2d2d743923096bd77177f',1,'Class.WorkbookService.OpenWorkbook()'],['../class_class_1_1_workbook_service_test_double.html#a4bfc1c71a00da4a17e0c6fe8c21f6a0f',1,'Class.WorkbookServiceTestDouble.OpenWorkbook()']]]
];
