var namespaces_dup =
[
    [ "Class", "namespace_class.html", "namespace_class" ],
    [ "Standard", "namespace_standard.html", "namespace_standard" ]
];