var searchData=
[
  ['valueexpression_0',['ValueExpression',['../class_class_1_1_detail_column_definition.html#ad003bc9cb5dfd4dd3a46baef1e2c8e24',1,'Class::DetailColumnDefinition']]]
];
