var searchData=
[
  ['xlookup_0',['XLookup',['../interface_class_1_1_i_worksheet_service.html#af70f30c72f1d141ce321c65e442f864f',1,'Class.IWorksheetService.XLookup()'],['../class_class_1_1_worksheet_service.html#a0f4c36f4a20add0af1e68c3e53408cbd',1,'Class.WorksheetService.XLookup()'],['../class_class_1_1_worksheet_service_test_double.html#aff5592c26d16bcaaed9bd94970437265',1,'Class.WorksheetServiceTestDouble.XLookup()']]]
];
