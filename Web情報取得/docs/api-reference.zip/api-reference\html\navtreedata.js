/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Web情報取得", "index.html", [
    [ "名前空間", "namespaces.html", [
      [ "名前空間一覧", "namespaces.html", "namespaces_dup" ]
    ] ],
    [ "クラス", "annotated.html", [
      [ "クラス一覧", "annotated.html", "annotated_dup" ],
      [ "クラス索引", "classes.html", null ],
      [ "クラス階層", "hierarchy.html", "hierarchy" ],
      [ "クラスメンバ", "functions.html", [
        [ "全て", "functions.html", "functions_dup" ],
        [ "関数", "functions_func.html", "functions_func" ],
        [ "変数", "functions_vars.html", null ],
        [ "プロパティ", "functions_prop.html", "functions_prop" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"class_class_1_1_file_system_service_test_double.html#aaee6511b0eb9050798512d70b5cbbc4c",
"class_class_1_1_test_double_behavior_store.html#a3ca70cc5135bf5da9207112a796c58c5",
"class_class_1_1_unit_test_assert.html#aae750fb0fce49fc25f60afbf2b580030",
"class_class_1_1_workbook_service_test_double.html#afd0efeabd48aa50ba03adcf3982e3ea9",
"class_class_1_1_worksheet_virtual_table_enumerator.html#a9af19535611a95418cb5a02af4e25de6",
"class_standard_1_1_lib___common.html#adf2cdd1e6a0c90d36eb0435d5277cc34",
"interface_class_1_1_i_stringable.html"
];

const SYNCONMSG = 'クリックで同期表示が無効になります';
const SYNCOFFMSG = 'クリックで同期表示が有効になります';
const LISTOFALLMEMBERS = '全メンバ一覧';