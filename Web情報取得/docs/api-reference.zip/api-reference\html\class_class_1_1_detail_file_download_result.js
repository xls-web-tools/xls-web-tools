var class_class_1_1_detail_file_download_result =
[
    [ "Initialize", "class_class_1_1_detail_file_download_result.html#ab1ccccf050304c0eb2e1464297a3e625", null ],
    [ "DownloadStatus", "class_class_1_1_detail_file_download_result.html#a83f680060bd6857ef1d248b42506f152", null ],
    [ "ErrorDescription", "class_class_1_1_detail_file_download_result.html#a9bb469158a8f8ea6473d77d285bd426e", null ],
    [ "RequiresDetailError", "class_class_1_1_detail_file_download_result.html#a5314e4d1903b82e4f9826d443a95768e", null ]
];