var class_class_1_1_output_sheet_writer =
[
    [ "Initialize", "class_class_1_1_output_sheet_writer.html#aab982b5c33ffa033827cb58fadaa117c", null ],
    [ "EnsureHeaders", "class_class_1_1_output_sheet_writer.html#ac7bfb2d67b8067f797e9ee5dfee24ebd", null ],
    [ "ShouldWriteExistingRow", "class_class_1_1_output_sheet_writer.html#ac3a6bbee6fad84a4c040fb5f0e94b2a6", null ]
];