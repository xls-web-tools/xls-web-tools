var interface_class_1_1_i_comparable =
[
    [ "CompareTo", "interface_class_1_1_i_comparable.html#a9f55f46cfa478a79d7ecad6298fd466c", null ],
    [ "IsGreaterThan", "interface_class_1_1_i_comparable.html#a13cc8980ebd79a88fe5ee27a4884a4e4", null ],
    [ "IsLessThan", "interface_class_1_1_i_comparable.html#a9842c1ead65711ef7909ac38bf6953d0", null ],
    [ "IsEqualTo", "interface_class_1_1_i_comparable.html#af3ff0b3f984865b3a546eca5166541b4", null ]
];