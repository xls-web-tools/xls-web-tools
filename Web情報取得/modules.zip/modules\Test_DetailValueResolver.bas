Attribute VB_Name = "Test_DetailValueResolver"
Option Explicit
Option Base 0

' #############################################################################
'!
'! @brief
'! DetailValueResolver �̃��j�b�g �e�X�g�ł��B
'! Lib_UnitTest.UnitTestMain() �ɂ���Ď��s����܂��B
'!
' #############################################################################

Public Sub Test_DetailValueResolver_�ʏ풊�o�񂾂���WebDriver���o�Ώۂɂ���(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#subject"))
    Call detail_defs.Add(New_DetailColumnDefinition("�����ʖ�", "", ValueExpression:="[����]"))

    Dim resolver As DetailValueResolver
    Set resolver = New DetailValueResolver

    ' --- Act ---
    Call resolver.Initialize(detail_defs)

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.EqualsNumeric 1, resolver.ExtractionColumnDefinitions.Count
    Assert.Equals "����", resolver.ExtractionColumnDefinitions.Item(0).OutputColumnName
End Sub

Public Sub Test_DetailValueResolver_�P����Q�Ƃ̔h���l����������(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#subject"))
    Call detail_defs.Add(New_DetailColumnDefinition("�����ʖ�", "", ValueExpression:="[����]"))

    Dim extraction_values As ArrayObject
    Set extraction_values = New ArrayObject
    Call extraction_values.ReDimArray(0, 0)
    Call extraction_values.Update(0, "�Č�A")

    Dim resolver As DetailValueResolver
    Set resolver = New DetailValueResolver
    Call resolver.Initialize(detail_defs)

    Dim actual_values As ArrayObject

    ' --- Act ---
    Set actual_values = resolver.ResolveValues(extraction_values)

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.Equals "�Č�A", CStr(actual_values.Item(1))
End Sub

Public Sub Test_DetailValueResolver_ValueExpression���ʂɒǉ�Trim���Ȃ�(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#subject"))
    Call detail_defs.Add(New_DetailColumnDefinition("�����ʖ�", "", ValueExpression:="[����]"))

    Dim extraction_values As ArrayObject
    Set extraction_values = New ArrayObject
    Call extraction_values.ReDimArray(0, 0)
    Call extraction_values.Update(0, "  �Č�A  ")

    Dim resolver As DetailValueResolver
    Set resolver = New DetailValueResolver
    Call resolver.Initialize(detail_defs)

    Dim actual_values As ArrayObject

    ' --- Act ---
    Set actual_values = resolver.ResolveValues(extraction_values)

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.Equals "  �Č�A  ", CStr(actual_values.Item(1))
End Sub

Public Sub Test_DetailValueResolver_IF�l���ŋ󗓎��̑�֒l��Ԃ�(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("��1", "#col1"))
    Call detail_defs.Add(New_DetailColumnDefinition("��2", "#col2"))
    Call detail_defs.Add(New_DetailColumnDefinition("�̗p��", "", ValueExpression:="IF([��2] == """", [��1], [��2])"))

    Dim resolver As DetailValueResolver
    Set resolver = New DetailValueResolver
    Call resolver.Initialize(detail_defs)

    Dim actual_values As ArrayObject

    ' --- Act ---
    Set actual_values = resolver.ResolveValues(pValues("A", ""))

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.Equals "A", CStr(actual_values.Item(2))
End Sub

Public Sub Test_DetailValueResolver_IF�����Ř_�����Z�q�ƃG�X�P�[�v���g����(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("�\����", "#requester"))
    Call detail_defs.Add(New_DetailColumnDefinition("�㗝�\����", "#proxy"))
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#subject"))
    Call detail_defs.Add(New_DetailColumnDefinition("����", "", ValueExpression:="IF(([�\����] == ""�R�c"" OR [�㗝�\����] == ""�R�c"") AND NOT [����] == ""A\""B\nC"", ""�Ώ�\n�s"", ""�ΏۊO"")"))

    Dim resolver As DetailValueResolver
    Set resolver = New DetailValueResolver
    Call resolver.Initialize(detail_defs)

    Dim actual_values As ArrayObject

    ' --- Act ---
    Set actual_values = resolver.ResolveValues(pValues("", "�R�c", "���̑�"))

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.Equals "�Ώ�" & vbLf & "�s", CStr(actual_values.Item(3))
End Sub

Public Sub Test_DetailValueResolver_�h���񂪑��̔h������Q�Ƃł���(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#source"))
    Call detail_defs.Add(New_DetailColumnDefinition("�ʖ�", "", ValueExpression:="[����]"))
    Call detail_defs.Add(New_DetailColumnDefinition("�ĕʖ�", "", ValueExpression:="[�ʖ�]"))

    Dim resolver As DetailValueResolver
    Set resolver = New DetailValueResolver
    Call resolver.Initialize(detail_defs)

    Dim actual_values As ArrayObject

    ' --- Act ---
    Set actual_values = resolver.ResolveValues(pValues("�Č�A"))

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.Equals "�Č�A", CStr(actual_values.Item(2))
End Sub

Public Sub Test_DetailValueResolver_�h����]�����͐ݒ�s���Ɉˑ����Ȃ�(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("�ĕʖ�", "", ValueExpression:="[�ʖ�]"))
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#source"))
    Call detail_defs.Add(New_DetailColumnDefinition("�ʖ�", "", ValueExpression:="[����]"))

    Dim resolver As DetailValueResolver
    Set resolver = New DetailValueResolver
    Call resolver.Initialize(detail_defs)

    Dim actual_values As ArrayObject

    ' --- Act ---
    Set actual_values = resolver.ResolveValues(pValues("�Č�A"))

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.Equals "�Č�A", CStr(actual_values.Item(0))
End Sub

Public Sub Test_DetailValueResolver_���Ή��֐��̓G���[(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#source"))
    Call detail_defs.Add(New_DetailColumnDefinition("�h��", "", ValueExpression:="COALESCE([����], """")"))

    Dim resolver As DetailValueResolver
    Set resolver = New DetailValueResolver

    ' --- Act ---
    Call resolver.Initialize(detail_defs)

    ' --- Assert ---
    If Not Assert.ErrorRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.IsTrue 0 < InStr(1, Err.Description, "ValueExpression", vbTextCompare)
End Sub

Public Sub Test_DetailValueResolver_�����񌋍��̓G���[(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#source"))
    Call detail_defs.Add(New_DetailColumnDefinition("�h��", "", ValueExpression:="""A"" & ""B"""))

    Dim resolver As DetailValueResolver
    Set resolver = New DetailValueResolver

    ' --- Act ---
    Call resolver.Initialize(detail_defs)

    ' --- Assert ---
    If Not Assert.ErrorRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.IsTrue 0 < InStr(1, Err.Description, "ValueExpression", vbTextCompare)
End Sub

Public Sub Test_DetailValueResolver_����`��Q�Ƃ̓G���[(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#source"))
    Call detail_defs.Add(New_DetailColumnDefinition("�h��", "", ValueExpression:="[����`]"))

    Dim resolver As DetailValueResolver
    Set resolver = New DetailValueResolver

    ' --- Act ---
    Call resolver.Initialize(detail_defs)

    ' --- Assert ---
    If Not Assert.ErrorRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.IsTrue 0 < InStr(1, Err.Description, "����`", vbTextCompare)
End Sub

Public Sub Test_DetailValueResolver_���ȎQ�Ƃ̓G���[(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����", "", ValueExpression:="[����]"))

    Dim resolver As DetailValueResolver
    Set resolver = New DetailValueResolver

    ' --- Act ---
    Call resolver.Initialize(detail_defs)

    ' --- Assert ---
    If Not Assert.ErrorRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.IsTrue 0 < InStr(1, Err.Description, "���ȎQ��", vbTextCompare)
End Sub

Public Sub Test_DetailValueResolver_�h���񓯎m�̏z�Q�Ƃ̓G���[(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("A", "", ValueExpression:="[B]"))
    Call detail_defs.Add(New_DetailColumnDefinition("B", "", ValueExpression:="[A]"))

    Dim resolver As DetailValueResolver
    Set resolver = New DetailValueResolver

    ' --- Act ---
    Call resolver.Initialize(detail_defs)

    ' --- Assert ---
    If Not Assert.ErrorRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.IsTrue 0 < InStr(1, Err.Description, "�z��", vbTextCompare)
End Sub

Private Function pValues(ParamArray Values() As Variant) As ArrayObject
    Dim result_values As ArrayObject
    Set result_values = New ArrayObject

    If LBound(Values) <= UBound(Values) Then
        Call result_values.ReDimArray(0, UBound(Values) - LBound(Values))
    End If

    Dim value_idx As Long
    For value_idx = LBound(Values) To UBound(Values)
        Call result_values.Update(value_idx - LBound(Values), Values(value_idx))
    Next value_idx

    Set pValues = result_values
End Function
