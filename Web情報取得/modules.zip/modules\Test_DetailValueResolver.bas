Attribute VB_Name = "Test_DetailValueResolver"
Option Explicit
Option Base 0

' #############################################################################
'!
'! @brief
'! DetailValueResolver �̃��j�b�g �e�X�g�ł��B
'! Lib_UnitTest.UnitTestMain() �ɂ���Ď��s����܂��B
'!
' #############################################################################

Public Sub Test_DetailValueResolver_�ʏ풊�o�񂾂���WebDriver���o�Ώۂɂ���(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#subject"))
    Call detail_defs.Add(New_DetailColumnDefinition("�����ʖ�", "", ValueExpression:="[����]"))

    Dim resolver As DetailValueResolver
    Set resolver = New DetailValueResolver

    ' --- Act ---
    Call resolver.Initialize(detail_defs)

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.EqualsNumeric 1, resolver.ExtractionColumnDefinitions.Count
    Assert.Equals "����", resolver.ExtractionColumnDefinitions.Item(0).OutputColumnName
End Sub

Public Sub Test_DetailValueResolver_�P����Q�Ƃ̔h���l����������(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#subject"))
    Call detail_defs.Add(New_DetailColumnDefinition("�����ʖ�", "", ValueExpression:="[����]"))

    Dim extraction_values As ArrayObject
    Set extraction_values = New ArrayObject
    Call extraction_values.ReDimArray(0, 0)
    Call extraction_values.Update(0, "�Č�A")

    Dim resolver As DetailValueResolver
    Set resolver = New DetailValueResolver
    Call resolver.Initialize(detail_defs)

    Dim actual_values As ArrayObject

    ' --- Act ---
    Set actual_values = resolver.ResolveValues(extraction_values)

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.Equals "�Č�A", CStr(actual_values.Item(1))
End Sub

Public Sub Test_DetailValueResolver_ValueExpression���ʂɒǉ�Trim���Ȃ�(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#subject"))
    Call detail_defs.Add(New_DetailColumnDefinition("�����ʖ�", "", ValueExpression:="[����]"))

    Dim extraction_values As ArrayObject
    Set extraction_values = New ArrayObject
    Call extraction_values.ReDimArray(0, 0)
    Call extraction_values.Update(0, "  �Č�A  ")

    Dim resolver As DetailValueResolver
    Set resolver = New DetailValueResolver
    Call resolver.Initialize(detail_defs)

    Dim actual_values As ArrayObject

    ' --- Act ---
    Set actual_values = resolver.ResolveValues(extraction_values)

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.Equals "  �Č�A  ", CStr(actual_values.Item(1))
End Sub
