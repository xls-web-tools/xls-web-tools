Attribute VB_Name = "Test_WebDriverProcess"
Option Explicit
Option Base 0

' #############################################################################
'!
'! @brief
'! WebDriver process �Ǘ��̃��j�b�g �e�X�g�ł��B
'! Lib_UnitTest.UnitTestMain() �ɂ���Ď��s����܂��B
'!
' #############################################################################

Public Sub Test_WebDriverProcess_WebDriver���s�t�@�C�����Ȃ��ꍇ�͔z�u�s���G���[(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.WebDriverPath = "C:\Missing\msedgedriver.exe"
    tool_settings.WebDriverPort = 9515

    Dim fs_stub As FileSystemServiceTestDouble
    Set fs_stub = New FileSystemServiceTestDouble

    Dim port_probe As WebDriverPortProbeTestDouble
    Set port_probe = New WebDriverPortProbeTestDouble

    Dim process As WebDriverProcess
    Set process = New_WebDriverProcess(fs_stub, port_probe)

    ' --- Act ---
    Call process.Start(tool_settings)

    ' --- Assert ---
    Assert.ErrorRaised 0, Err.Number, Err.Source, Err.Description
    Assert.IsTrue 0 < InStr(1, Err.Description, "�z�u", vbTextCompare)
    Assert.EqualsNumeric 1, fs_stub.Store.GetCallCount("IsFile", "C:\Missing\msedgedriver.exe")
    Assert.EqualsNumeric 0, port_probe.Store.GetCallCount("IsPortInUse", CLng(9515))
    Assert.IsFalse process.IsRunning
End Sub

Public Sub Test_WebDriverProcess_����Port���g�p���̏ꍇ�͑��v���Z�X���I���������f����(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.WebDriverPath = "C:\Driver\msedgedriver.exe"
    tool_settings.WebDriverPort = 9515

    Dim fs_stub As FileSystemServiceTestDouble
    Set fs_stub = New FileSystemServiceTestDouble
    Call fs_stub.Store.SetReturn("IsFile", True, "C:\Driver\msedgedriver.exe")

    Dim port_probe As WebDriverPortProbeTestDouble
    Set port_probe = New WebDriverPortProbeTestDouble
    Call port_probe.Store.SetReturn("IsPortInUse", True, CLng(9515))

    Dim process As WebDriverProcess
    Set process = New_WebDriverProcess(fs_stub, port_probe)

    ' --- Act ---
    Call process.Start(tool_settings)

    ' --- Assert ---
    Assert.ErrorRaised 0, Err.Number, Err.Source, Err.Description
    Assert.IsTrue 0 < InStr(1, Err.Description, "�g�p��", vbTextCompare)
    Assert.EqualsNumeric 1, fs_stub.Store.GetCallCount("IsFile", "C:\Driver\msedgedriver.exe")
    Assert.EqualsNumeric 1, port_probe.Store.GetCallCount("IsPortInUse", CLng(9515))
    Assert.IsFalse process.IsRunning
End Sub
