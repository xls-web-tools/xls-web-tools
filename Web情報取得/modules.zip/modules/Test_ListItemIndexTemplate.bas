Attribute VB_Name = "Test_ListItemIndexTemplate"
Option Explicit
Option Base 0

' #############################################################################
'!
'! @brief
'! �ꗗ���� index �e���v���[�g�̃��j�b�g �e�X�g�ł��B
'! Lib_UnitTest.UnitTestMain() �ɂ���Ď��s����܂��B
'!
' #############################################################################

Public Sub Test_ListItemIndexTemplate_Index��RowNumber��u������(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim index_template As ListItemIndexTemplate
    Set index_template = New_ListItemIndexTemplate()

    ' --- Act ---
    Dim actual_value As String
    actual_value = index_template.Apply("#list tr:nth-child({{rowNumber}}) a[data-index='{{index}}']", 2)

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.Equals "#list tr:nth-child(3) a[data-index='2']", actual_value
End Sub

Public Sub Test_ListItemIndexTemplate_�u���g�[�N�����Ȃ���Ό��̕������Ԃ�(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim index_template As ListItemIndexTemplate
    Set index_template = New_ListItemIndexTemplate()

    ' --- Act ---
    Dim actual_value As String
    actual_value = index_template.Apply("#target-id", 4)

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.Equals "#target-id", actual_value
End Sub
