Attribute VB_Name = "Test_ColumnExpression"
Option Explicit
Option Base 0

Public Sub Test_ColumnExpression_ANDOR������]���ł���(ByVal Assert As UnitTestAssert)
    Dim expression As ColumnExpression
    Set expression = New_ColumnExpression("([�\����] == ""�R�c"" OR [�㗝�\����] == ""�R�c"") AND [�����ςݓ�] != ""��""", G_COLUMN_EXPRESSION_KIND_CONDITION, "OutputConditionExpression")

    Dim column_values As ObjectDictionary
    Set column_values = pColumnValues( _
            "�\����", "", _
            "�㗝�\����", "�R�c", _
            "�����ςݓ�", "")

    Dim actual As Boolean

    On Error Resume Next
    actual = expression.EvaluateCondition(column_values)
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    On Error GoTo 0

    Call Assert.IsTrue(actual, "��l�������Ɉ�v����ꍇ�� True")
End Sub

Public Sub Test_ColumnExpression_�����s��v��False��Ԃ�(ByVal Assert As UnitTestAssert)
    Dim expression As ColumnExpression
    Set expression = New_ColumnExpression("[���] == ""����""", G_COLUMN_EXPRESSION_KIND_CONDITION, "OutputConditionExpression")

    Dim actual As Boolean

    On Error Resume Next
    actual = expression.EvaluateCondition(pColumnValues("���", "������"))
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    On Error GoTo 0

    Call Assert.IsFalse(actual, "��l�������Ɉ�v���Ȃ��ꍇ�� False")
End Sub

Public Sub Test_ColumnExpression_�Q�Ɨ񖼂͓o�ꏇ�ŏd����������(ByVal Assert As UnitTestAssert)
    Dim expression As ColumnExpression
    Set expression = New_ColumnExpression("([A] == ""x"" OR [B] == ""y"") AND [A] != ""z""", G_COLUMN_EXPRESSION_KIND_CONDITION, "OutputConditionExpression")

    Dim actual_names As ObjectList

    On Error Resume Next
    Set actual_names = expression.ReferencedColumnNames
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    On Error GoTo 0

    Assert.EqualsNumeric 2, actual_names.Count
    Assert.Equals "A", CStr(actual_names.Item(0))
    Assert.Equals "B", CStr(actual_names.Item(1))
End Sub

Public Sub Test_ColumnExpression_IF�l���͑I�������}�����]������(ByVal Assert As UnitTestAssert)
    Dim expression As ColumnExpression
    Set expression = New_ColumnExpression("IF([����] == ""Y"", [����], [������])", G_COLUMN_EXPRESSION_KIND_VALUE, "ValueExpression(�̗p��)")

    Dim actual As String

    On Error Resume Next
    actual = expression.EvaluateValue(pColumnValues("����", "Y", "����", "�̗p�l"))
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    On Error GoTo 0

    Assert.Equals "�̗p�l", actual
End Sub

Public Sub Test_ColumnExpression_OR�����͍���True�Ȃ�E��]�����Ȃ�(ByVal Assert As UnitTestAssert)
    Dim expression As ColumnExpression
    Set expression = New_ColumnExpression("[A] == ""x"" OR [������] == ""y""", G_COLUMN_EXPRESSION_KIND_CONDITION, "OutputConditionExpression")

    Dim actual As Boolean

    On Error Resume Next
    actual = expression.EvaluateCondition(pColumnValues("A", "x"))
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    On Error GoTo 0

    Assert.IsTrue actual
End Sub

Public Sub Test_ColumnExpression_�����񃊃e�����̃G�X�P�[�v�����߂���(ByVal Assert As UnitTestAssert)
    Dim expression As ColumnExpression
    Set expression = New_ColumnExpression("[����] == ""A\""B\nC""", G_COLUMN_EXPRESSION_KIND_CONDITION, "OutputConditionExpression")

    Dim actual As Boolean

    On Error Resume Next
    actual = expression.EvaluateCondition(pColumnValues("����", "A" & Chr$(34) & "B" & vbLf & "C"))
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    On Error GoTo 0

    Assert.IsTrue actual
End Sub

Public Sub Test_ColumnExpression_��r�������O��󔒂���������(ByVal Assert As UnitTestAssert)
    Dim expression As ColumnExpression
    Set expression = New_ColumnExpression("[����] == "" �Č�A """, G_COLUMN_EXPRESSION_KIND_CONDITION, "OutputConditionExpression")

    Dim actual As Boolean

    On Error Resume Next
    actual = expression.EvaluateCondition(pColumnValues("����", "  �Č�A  "))
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    On Error GoTo 0

    Assert.IsTrue actual
End Sub

Public Sub Test_ColumnExpression_ValueExpression���ʂɒǉ�Trim���Ȃ�(ByVal Assert As UnitTestAssert)
    Dim expression As ColumnExpression
    Set expression = New_ColumnExpression("[����]", G_COLUMN_EXPRESSION_KIND_VALUE, "ValueExpression(�����ʖ�)")

    Dim actual As String

    On Error Resume Next
    actual = expression.EvaluateValue(pColumnValues("����", "  �Č�A  "))
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    On Error GoTo 0

    Assert.Equals "  �Č�A  ", actual
End Sub

Public Sub Test_ColumnExpression_���mescape�͏��������ɃG���[(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    Dim expression As ColumnExpression
    Set expression = New_ColumnExpression("[����] == ""A\x""", G_COLUMN_EXPRESSION_KIND_CONDITION, "OutputConditionExpression")

    If Not Assert.ErrorRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.IsTrue 0 < InStr(1, Err.Description, "���m", vbTextCompare)
End Sub

Public Sub Test_ColumnExpression_����`��Q�Ƃ͕]�����ɃG���[(ByVal Assert As UnitTestAssert)
    Dim expression As ColumnExpression
    Set expression = New_ColumnExpression("[����`] == """"", G_COLUMN_EXPRESSION_KIND_CONDITION, "OutputConditionExpression")

    Dim column_values As ObjectDictionary
    Set column_values = New_ObjectDictionary()

    On Error Resume Next
    Call expression.EvaluateCondition(column_values)

    If Not Assert.ErrorRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.IsTrue 0 < InStr(1, Err.Description, "����`", vbTextCompare)
End Sub

Public Sub Test_ColumnExpression_OutputColumnName�召�Ⴂ�͕ʗ�Ƃ��ĎQ�Ƃł���(ByVal Assert As UnitTestAssert)
    Dim expression As ColumnExpression
    Set expression = New_ColumnExpression("[Name] == ""UPPER"" AND [name] == ""LOWER""", G_COLUMN_EXPRESSION_KIND_CONDITION, "OutputConditionExpression")

    Dim actual As Boolean

    On Error Resume Next
    actual = expression.EvaluateCondition(pColumnValues("Name", "UPPER", "name", "LOWER"))
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    On Error GoTo 0

    Assert.IsTrue actual
End Sub

Public Sub Test_ColumnExpression_LF���܂ޗ񖼂���LF�ŎQ�Ƃł���(ByVal Assert As UnitTestAssert)
    Dim column_name As String
    column_name = "����" & vbLf & "�ڍ�"

    Dim expression As ColumnExpression
    Set expression = New_ColumnExpression("[" & column_name & "] == ""�Č�A""", G_COLUMN_EXPRESSION_KIND_CONDITION, "OutputConditionExpression")

    Dim actual As Boolean

    On Error Resume Next
    actual = expression.EvaluateCondition(pColumnValues(column_name, "�Č�A"))
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    On Error GoTo 0

    Assert.IsTrue actual
End Sub

Public Sub Test_ColumnExpression_��Q�Ɠ�backslashn��LF�Ƃ��Ĉ���Ȃ�(ByVal Assert As UnitTestAssert)
    Dim column_name As String
    column_name = "����" & vbLf & "�ڍ�"

    Dim expression As ColumnExpression
    Set expression = New_ColumnExpression("[����\n�ڍ�] == ""�Č�A""", G_COLUMN_EXPRESSION_KIND_CONDITION, "OutputConditionExpression")

    On Error Resume Next
    Call expression.EvaluateCondition(pColumnValues(column_name, "�Č�A"))

    If Not Assert.ErrorRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.IsTrue 0 < InStr(1, Err.Description, "����`", vbTextCompare)
End Sub

Private Function pColumnValues(ParamArray Pairs() As Variant) As ObjectDictionary
    Dim result_values As ObjectDictionary
    Set result_values = New_ObjectDictionary()

    Dim pair_idx As Long
    If LBound(Pairs) <= UBound(Pairs) Then
        For pair_idx = LBound(Pairs) To UBound(Pairs) Step 2
            Call result_values.Add(CStr(Pairs(pair_idx)), CStr(Pairs(pair_idx + 1)))
        Next pair_idx
    End If

    Set pColumnValues = result_values
End Function
