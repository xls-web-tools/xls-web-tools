Attribute VB_Name = "Test_WebCollectionRunner"
Option Explicit
Option Base 0

' #############################################################################
'!
'! @brief
'! Web collection runner �̃��j�b�g �e�X�g�ł��B
'! Lib_UnitTest.UnitTestMain() �ɂ���Ď��s����܂��B
'!
' #############################################################################

Public Sub Test_WebCollectionRunner_���݃y�[�W��Ώ�ID��L�[�ŏ��񂵊���OK�̓X�L�b�v����(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim wb_stub As WorkbookServiceTestDouble
    Set wb_stub = New WorkbookServiceTestDouble
    Set WbSrv = wb_stub

    Dim ws_stub As WorksheetServiceTestDouble
    Set ws_stub = New WorksheetServiceTestDouble
    Set WsSrv = ws_stub
    Call pSetManagedHeadersBlank(ws_stub, False)
    Call pPrepareEmptyOutput(ws_stub)

    Dim fs_stub As FileSystemServiceTestDouble
    Set fs_stub = New FileSystemServiceTestDouble
    Call fs_stub.Store.SetReturn("CreateTemporaryDirectory", "C:\Temp\xls-web-tools_tmp123.tmp", "xls-web-tools_")

    Dim staging_files() As String
    staging_files = EmptyStringArray()
    Call fs_stub.Store.SetReturn("GetFileList", staging_files, "C:\Temp\xls-web-tools_tmp123.tmp", "", "", True)

    Dim crdownload_files() As String
    crdownload_files = EmptyStringArray()
    Call fs_stub.Store.SetReturn("GetFileList", crdownload_files, "C:\Temp\xls-web-tools_tmp123.tmp", "\.(crdownload|tmp)$", "", True)

    Dim completed_files(0 To 0) As String
    completed_files(0) = "C:\Temp\xls-web-tools_tmp123.tmp\report.pdf"
    Call fs_stub.Store.SetReturn("GetFileList", completed_files, "C:\Temp\xls-web-tools_tmp123.tmp", "", "\.(crdownload|tmp)$", True)
    Call fs_stub.Store.SetReturn("IsFile", True, "C:\Temp\xls-web-tools_tmp123.tmp\report.pdf")
    Call fs_stub.Store.SetReturn("GetFileSize", 1024#, "C:\Temp\xls-web-tools_tmp123.tmp\report.pdf")
    Call fs_stub.Store.SetReturn("CreateDirectory", True, "D:\Root\T-002", False, True)
    Call fs_stub.Store.SetReturn("IsDirectory", True, "C:\Profile")
    Set FsSrv = fs_stub

    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"
    tool_settings.StartUrl = "https://example.test/start"
    tool_settings.OutputSheetName = "output"
    tool_settings.AuthenticatedStartSelector = "#top-ready"
    tool_settings.ListTransitionOperationName = "OpenList"
    tool_settings.ListItemSelector = "#list tbody tr"
    tool_settings.ListItemTargetIdSelector = "#list tbody tr:nth-child({{rowNumber}}) td.id"
    tool_settings.DetailTransitionOperationName = "OpenDetail"
    tool_settings.TargetIdSelector = "#target-id"
    tool_settings.ReturnToListOperationName = "ReturnToList"
    tool_settings.ExistingRowMode = G_WEB_ROW_MODE_SKIP_EXISTING
    tool_settings.TimeoutSeconds = 1
    tool_settings.DownloadEnabled = True
    tool_settings.DownloadRootPath = "D:\Root"
    tool_settings.DownloadLinkSelector = "#download"

    Dim operations As ObjectList
    Set operations = New_ObjectList("TransitionOperation")
    Call operations.Add(New_TransitionOperation("OpenList", "#open-list", WaitSelector:="#list-ready"))
    Call operations.Add(New_TransitionOperation("OpenDetail", "", ActionScript:="openDetail({{index}})", WaitSelector:="#target-id"))
    Call operations.Add(New_TransitionOperation("ReturnToList", "#return-list", WaitSelector:="#list-ready"))
    Set tool_settings.TransitionOperations = operations

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#subject"))
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#decision"))
    Set tool_settings.DetailColumnDefinitions = detail_defs

    Call pPrepareExistingOutputRows(ws_stub)

    Dim create_body As String
    create_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""],""prefs"":{""download.default_directory"":""C:\\Temp\\xls-web-tools_tmp123.tmp"",""download.prompt_for_download"":false,""download.directory_upgrade"":true}}}}}"

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", create_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/url", "{""url"":""https://example.test/start""}")
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""auth-element""}}", "POST", "/session/abc/element", pCssFindBody("#top-ready"))
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""open-list-element""}}", "POST", "/session/abc/element", pCssFindBody("#open-list"))
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/element/open-list-element/click", "{}")
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""list-element""}}", "POST", "/session/abc/element", pCssFindBody("#list-ready"))
    Call client_double.Store.SetReturn("Execute", "{""value"":[{""element-6066-11e4-a52e-4f735466cecf"":""row-1""},{""element-6066-11e4-a52e-4f735466cecf"":""row-2""}]}", "POST", "/session/abc/elements", pCssFindBody("#list tbody tr"))
    Call pSetTextElement(client_double, "#list tbody tr:nth-child(1) td.id", "list-target-1", "T-001")
    Call pSetTextElement(client_double, "#list tbody tr:nth-child(2) td.id", "list-target-2", "T-002")
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/execute/sync", "{""script"":""openDetail(1)"",""args"":[]}")
    Call pSetTextElement(client_double, "#target-id", "target-element", "T-002")
    Call client_double.Store.SetReturn("Execute.AnyRequestBody", "{""value"": [""�Č�B"", ""�Ώ�""]}", "POST", "/session/abc/execute/sync")
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/frame", "{""id"":null}")
    Call client_double.Store.SetReturn("Execute", "{""value"":[{""element-6066-11e4-a52e-4f735466cecf"":""download-1""}]}", "POST", "/session/abc/elements", pCssFindBody("#download"))
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""download-1""}}", "POST", "/session/abc/element", pCssFindBody("#download"))
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/element/download-1/click", "{}")
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""return-list-element""}}", "POST", "/session/abc/element", pCssFindBody("#return-list"))
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/element/return-list-element/click", "{}")
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "DELETE", "/session/abc", "")

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    Dim process As WebDriverProcessTestDouble
    Set process = New WebDriverProcessTestDouble

    Set ProgStat = Nothing

    Dim lifecycle As WebDriverSessionLifecycle
    Set lifecycle = New_WebDriverSessionLifecycle(process, session_client, tool_settings)

    Dim runner As WebCollectionRunner
    Set runner = New_WebCollectionRunner(lifecycle, tool_settings)

    ' --- Act ---
    Dim actual_session_id As String
    actual_session_id = runner.Run()

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.Equals "abc", actual_session_id
    Assert.EqualsNumeric 1, runner.SucceededCount
    Assert.EqualsNumeric 1, runner.SkippedCount
    Assert.EqualsNumeric 0, runner.ErrorCount
    Assert.EqualsNumeric 1, runner.PageCount
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/execute/sync", "{""script"":""openDetail(1)"",""args"":[]}")
    Assert.EqualsNumeric 0, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/execute/sync", "{""script"":""openDetail(0)"",""args"":[]}")
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element/return-list-element/click", "{}")
    Assert.EqualsNumeric 1, process.Store.GetCallCount("StopProcess")
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "DELETE", "/session/abc", "")
    Call pAssertWrittenCell(Assert, ws_stub, 6, 1, "T-002")
    Call pAssertWrittenCell(Assert, ws_stub, 6, 2, G_WEB_STATUS_OK)
    Call pAssertWrittenCell(Assert, ws_stub, 6, 3, "")
    Call pAssertWrittenCell(Assert, ws_stub, 6, 4, G_WEB_DOWNLOAD_STATUS_DOWNLOADED)
    Call pAssertWrittenCell(Assert, ws_stub, 6, 5, "�Č�B")
    Assert.EqualsNumeric 0, ws_stub.Store.GetCallCount("WriteCell", New_RangeBounds(Row:=6, Column:=6, Sheet:="output"))
    Assert.EqualsNumeric 1, fs_stub.Store.GetCallCount("MoveFile", "C:\Temp\xls-web-tools_tmp123.tmp\report.pdf", "D:\Root\T-002\002_report.pdf", False)
    Assert.EqualsNumeric 0, ws_stub.Store.GetCallCount("WriteCell", New_RangeBounds(Row:=5, Column:=2, Sheet:="output"))
    Assert.IsNothing ProgStat
End Sub

Public Sub Test_WebCollectionRunner_����y�[�W0���Ȃ���W�i�����J�n���Ȃ�(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim wb_stub As WorkbookServiceTestDouble
    Set wb_stub = New WorkbookServiceTestDouble
    Set WbSrv = wb_stub

    Dim ws_stub As WorksheetServiceTestDouble
    Set ws_stub = New WorksheetServiceTestDouble
    Set WsSrv = ws_stub
    Call pSetManagedHeadersBlank(ws_stub, False)
    Call pPrepareEmptyOutput(ws_stub)

    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"
    tool_settings.StartUrl = "https://example.test/start"
    tool_settings.OutputSheetName = "output"
    tool_settings.AuthenticatedStartSelector = "#top-ready"
    tool_settings.ListTransitionOperationName = "OpenList"
    tool_settings.ListItemSelector = "#list tbody tr"
    tool_settings.ListItemTargetIdSelector = "#list tbody tr:nth-child({{rowNumber}}) td.id"
    tool_settings.DetailTransitionOperationName = "OpenDetail"
    tool_settings.TargetIdSelector = "#target-id"
    tool_settings.ReturnToListOperationName = "ReturnToList"
    tool_settings.ExistingRowMode = G_WEB_ROW_MODE_SKIP_EXISTING
    tool_settings.TimeoutSeconds = 1

    Dim operations As ObjectList
    Set operations = New_ObjectList("TransitionOperation")
    Call operations.Add(New_TransitionOperation("OpenList", "#open-list", WaitSelector:="#list-ready"))
    Call operations.Add(New_TransitionOperation("OpenDetail", "", ActionScript:="openDetail({{index}})", WaitSelector:="#target-id"))
    Call operations.Add(New_TransitionOperation("ReturnToList", "#return-list", WaitSelector:="#list-ready"))
    Set tool_settings.TransitionOperations = operations

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Set tool_settings.DetailColumnDefinitions = detail_defs

    Dim create_body As String
    create_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""]}}}}"

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", create_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/url", "{""url"":""https://example.test/start""}")
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""auth-element""}}", "POST", "/session/abc/element", pCssFindBody("#top-ready"))
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""open-list-element""}}", "POST", "/session/abc/element", pCssFindBody("#open-list"))
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/element/open-list-element/click", "{}")
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""list-element""}}", "POST", "/session/abc/element", pCssFindBody("#list-ready"))
    Call client_double.Store.SetReturn("Execute", "{""value"":[]}", "POST", "/session/abc/elements", pCssFindBody("#list tbody tr"))
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "DELETE", "/session/abc", "")

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    Dim process As WebDriverProcessTestDouble
    Set process = New WebDriverProcessTestDouble

    Set ProgStat = New ProgressStatus
    Application.StatusBar = False

    Dim lifecycle As WebDriverSessionLifecycle
    Set lifecycle = New_WebDriverSessionLifecycle(process, session_client, tool_settings)

    Dim runner As WebCollectionRunner
    Set runner = New_WebCollectionRunner(lifecycle, tool_settings)

    ' --- Act ---
    Dim actual_session_id As String
    actual_session_id = runner.Run()

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.Equals "abc", actual_session_id
    Assert.EqualsNumeric 1, runner.PageCount
    Assert.Equals "�擾������", ProgStat.TaskName
    Assert.EqualsNumeric 5, ProgStat.TotalValue
    Assert.EqualsNumeric 5, ProgStat.ProcessedValue
    Assert.IsTrue ProgStat.IsComplete
    Assert.Equals False, CBool(Application.StatusBar)
End Sub

Public Sub Test_WebCollectionRunner_����ERROR�s�������s��v�Ȃ�����s���X�V�����o�͑ΏۊO�ɐ�����(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim wb_stub As WorkbookServiceTestDouble
    Set wb_stub = New WorkbookServiceTestDouble
    Set WbSrv = wb_stub

    Dim ws_stub As WorksheetServiceTestDouble
    Set ws_stub = New WorksheetServiceTestDouble
    Set WsSrv = ws_stub
    Call pSetManagedHeadersBlank(ws_stub, False)
    Call pPrepareEmptyOutput(ws_stub)

    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"
    tool_settings.StartUrl = "https://example.test/start"
    tool_settings.OutputSheetName = "output"
    tool_settings.AuthenticatedStartSelector = "#top-ready"
    tool_settings.ListTransitionOperationName = "OpenList"
    tool_settings.ListItemSelector = "#list tbody tr"
    tool_settings.ListItemTargetIdSelector = "#list tbody tr:nth-child({{rowNumber}}) td.id"
    tool_settings.DetailTransitionOperationName = "OpenDetail"
    tool_settings.TargetIdSelector = "#target-id"
    tool_settings.ReturnToListOperationName = "ReturnToList"
    tool_settings.ExistingRowMode = G_WEB_ROW_MODE_SKIP_EXISTING
    tool_settings.OutputConditionExpression = "[����] == ""�Ώ�"""
    tool_settings.TimeoutSeconds = 1

    Dim operations As ObjectList
    Set operations = New_ObjectList("TransitionOperation")
    Call operations.Add(New_TransitionOperation("OpenList", "#open-list", WaitSelector:="#list-ready"))
    Call operations.Add(New_TransitionOperation("OpenDetail", "", ActionScript:="openDetail({{index}})", WaitSelector:="#target-id"))
    Call operations.Add(New_TransitionOperation("ReturnToList", "#return-list", WaitSelector:="#list-ready"))
    Set tool_settings.TransitionOperations = operations

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#decision"))
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#subject", IsRequired:=True, BlankMode:="ErrorIfBlank"))
    Set tool_settings.DetailColumnDefinitions = detail_defs

    Dim output_target_search_bounds As WorksheetRangeBounds
    Set output_target_search_bounds = New_RangeBounds(Row:=2, Column:=1, FinishRow:=G_ROW_MAX, FinishColumn:=1, Sheet:="output")

    Dim output_found_rows As ObjectList
    Set output_found_rows = New_ObjectList("WorksheetRangeBounds")
    Call output_found_rows.Add(New_RangeBounds(Row:=6, Column:=1, Sheet:="output"))
    Call ws_stub.Store.SetReturn("Find", output_found_rows, "T-001", output_target_search_bounds, True, True, True, True)
    Call ws_stub.Store.SetReturn("ReadCell", G_WEB_STATUS_ERROR, New_RangeBounds(Row:=6, Column:=2, Sheet:="output"), False)

    Dim create_body As String
    create_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""]}}}}"

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", create_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/url", "{""url"":""https://example.test/start""}")
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""auth-element""}}", "POST", "/session/abc/element", pCssFindBody("#top-ready"))
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""open-list-element""}}", "POST", "/session/abc/element", pCssFindBody("#open-list"))
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/element/open-list-element/click", "{}")
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""list-element""}}", "POST", "/session/abc/element", pCssFindBody("#list-ready"))
    Call client_double.Store.SetReturn("Execute", "{""value"": [{""element-6066-11e4-a52e-4f735466cecf"":""row-1""}]}", "POST", "/session/abc/elements", pCssFindBody("#list tbody tr"))
    Call pSetTextElement(client_double, "#list tbody tr:nth-child(1) td.id", "list-target-1", "T-001")
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/execute/sync", "{""script"":""openDetail(0)"",""args"":[]}")
    Call pSetTextElement(client_double, "#target-id", "target-element", "T-001")
    Call client_double.Store.SetReturn("Execute.AnyRequestBody", "{""value"": [""�ΏۊO""]}", "POST", "/session/abc/execute/sync")
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""return-list-element""}}", "POST", "/session/abc/element", pCssFindBody("#return-list"))
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/element/return-list-element/click", "{}")
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "DELETE", "/session/abc", "")

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    Dim process As WebDriverProcessTestDouble
    Set process = New WebDriverProcessTestDouble

    Set ProgStat = Nothing

    Dim lifecycle As WebDriverSessionLifecycle
    Set lifecycle = New_WebDriverSessionLifecycle(process, session_client, tool_settings)

    Dim runner As WebCollectionRunner
    Set runner = New_WebCollectionRunner(lifecycle, tool_settings)

    ' --- Act ---
    Dim actual_session_id As String
    actual_session_id = runner.Run()

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.Equals "abc", actual_session_id
    Assert.EqualsNumeric 0, runner.SucceededCount
    Assert.EqualsNumeric 0, runner.SkippedCount
    Assert.EqualsNumeric 1, runner.OutputExcludedCount
    Assert.EqualsNumeric 0, runner.ErrorCount
    Assert.EqualsNumeric 1, runner.PageCount
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element/return-list-element/click", "{}")
    Assert.EqualsNumeric 0, ws_stub.Store.GetCallCount("WriteCell", New_RangeBounds(Row:=2, Column:=1, Sheet:="output"))
    Assert.EqualsNumeric 0, ws_stub.Store.GetCallCount("WriteCell", New_RangeBounds(Row:=6, Column:=2, Sheet:="output"))
    Assert.EqualsNumeric 1, process.Store.GetCallCount("StopProcess")
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "DELETE", "/session/abc", "")
End Sub

Public Sub Test_WebCollectionRunner_���y�[�W������ΑS�y�[�W�����񂷂�(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim wb_stub As WorkbookServiceTestDouble
    Set wb_stub = New WorkbookServiceTestDouble
    Set WbSrv = wb_stub

    Dim ws_stub As WorksheetServiceTestDouble
    Set ws_stub = New WorksheetServiceTestDouble
    Set WsSrv = ws_stub
    Call pSetManagedHeadersBlank(ws_stub, False)
    Call pPrepareEmptyOutput(ws_stub)

    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"
    tool_settings.StartUrl = "https://example.test/start"
    tool_settings.OutputSheetName = "output"
    tool_settings.AuthenticatedStartSelector = "#top-ready"
    tool_settings.ListTransitionOperationName = "OpenList"
    tool_settings.ListItemSelector = "#list tbody tr"
    tool_settings.ListItemTargetIdSelector = "#list tbody tr:nth-child({{rowNumber}}) td.id"
    tool_settings.DetailTransitionOperationName = "OpenDetail"
    tool_settings.TargetIdSelector = "#target-id"
    tool_settings.ReturnToListOperationName = "ReturnToList"
    tool_settings.NextPageOperationName = "NextPage"
    tool_settings.NextPageAvailableSelector = "#next-page"
    tool_settings.ExistingRowMode = G_WEB_ROW_MODE_SKIP_EXISTING
    tool_settings.TimeoutSeconds = 1

    Dim operations As ObjectList
    Set operations = New_ObjectList("TransitionOperation")
    Call operations.Add(New_TransitionOperation("OpenList", "#open-list", WaitSelector:="#list-ready"))
    Call operations.Add(New_TransitionOperation("OpenDetail", "", ActionScript:="openDetail({{index}})", WaitSelector:="#target-id"))
    Call operations.Add(New_TransitionOperation("ReturnToList", "#return-list", WaitSelector:="#list-ready"))
    Call operations.Add(New_TransitionOperation("NextPage", "#next-link", WaitSelector:="#list-ready"))
    Set tool_settings.TransitionOperations = operations

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Set tool_settings.DetailColumnDefinitions = detail_defs

    Call pPrepareExistingOkOutputRows(ws_stub)

    Dim create_body As String
    create_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""]}}}}"

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", create_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/url", "{""url"":""https://example.test/start""}")
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""auth-element""}}", "POST", "/session/abc/element", pCssFindBody("#top-ready"))
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""open-list-element""}}", "POST", "/session/abc/element", pCssFindBody("#open-list"))
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/element/open-list-element/click", "{}")
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""list-element""}}", "POST", "/session/abc/element", pCssFindBody("#list-ready"))
    Call client_double.Store.SetReturn("Execute.Sequence", "{""value"":[{""element-6066-11e4-a52e-4f735466cecf"":""row-page-1""}]}", "POST", "/session/abc/elements", pCssFindBody("#list tbody tr"), CLng(0))
    Call client_double.Store.SetReturn("Execute.Sequence", "{""value"":[{""element-6066-11e4-a52e-4f735466cecf"":""row-page-2""}]}", "POST", "/session/abc/elements", pCssFindBody("#list tbody tr"), CLng(1))
    Call client_double.Store.SetReturn("Execute.Sequence", "{""value"":[{""element-6066-11e4-a52e-4f735466cecf"":""next-page""}]}", "POST", "/session/abc/elements", pCssFindBody("#next-page"), CLng(0))
    Call client_double.Store.SetReturn("Execute.Sequence", "{""value"":[]}", "POST", "/session/abc/elements", pCssFindBody("#next-page"), CLng(1))
    Call pSetTextElementSequence(client_double, "#list tbody tr:nth-child(1) td.id", "list-target", Array("T-001", "T-001", "T-002", "T-002", "T-002"))
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""next-link-element""}}", "POST", "/session/abc/element", pCssFindBody("#next-link"))
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/element/next-link-element/click", "{}")
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "DELETE", "/session/abc", "")

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    Dim process As WebDriverProcessTestDouble
    Set process = New WebDriverProcessTestDouble

    Set ProgStat = New ProgressStatus

    Dim lifecycle As WebDriverSessionLifecycle
    Set lifecycle = New_WebDriverSessionLifecycle(process, session_client, tool_settings)

    Dim runner As WebCollectionRunner
    Set runner = New_WebCollectionRunner(lifecycle, tool_settings)

    ' --- Act ---
    Dim actual_session_id As String
    actual_session_id = runner.Run()

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.Equals "abc", actual_session_id
    Assert.EqualsNumeric 0, runner.SucceededCount
    Assert.EqualsNumeric 2, runner.SkippedCount
    Assert.EqualsNumeric 0, runner.ErrorCount
    Assert.EqualsNumeric 2, runner.PageCount
    Assert.Equals "�擾��", ProgStat.TaskName
    Assert.EqualsNumeric 2, ProgStat.TotalValue
    Assert.EqualsNumeric 2, ProgStat.ProcessedValue
    Assert.IsTrue ProgStat.IsComplete
    Assert.Equals False, CBool(Application.StatusBar)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element/next-link-element/click", "{}")
    Assert.EqualsNumeric 0, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/execute/sync", "{""script"":""openDetail(0)"",""args"":[]}")
    Assert.EqualsNumeric 0, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/execute/sync", "{""script"":""openDetail(1)"",""args"":[]}")
    Assert.EqualsNumeric 1, process.Store.GetCallCount("StopProcess")
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "DELETE", "/session/abc", "")
End Sub

Public Sub Test_WebCollectionRunner_���y�[�W�����ɐ擪�Ώ�ID���ς��Ȃ���Β��f����(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim wb_stub As WorkbookServiceTestDouble
    Set wb_stub = New WorkbookServiceTestDouble
    Set WbSrv = wb_stub

    Dim ws_stub As WorksheetServiceTestDouble
    Set ws_stub = New WorksheetServiceTestDouble
    Set WsSrv = ws_stub
    Call pSetManagedHeadersBlank(ws_stub, False)
    Call pPrepareEmptyOutput(ws_stub)

    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"
    tool_settings.StartUrl = "https://example.test/start"
    tool_settings.OutputSheetName = "output"
    tool_settings.AuthenticatedStartSelector = "#top-ready"
    tool_settings.ListTransitionOperationName = "OpenList"
    tool_settings.ListItemSelector = "#list tbody tr"
    tool_settings.ListItemTargetIdSelector = "#list tbody tr:nth-child({{rowNumber}}) td.id"
    tool_settings.DetailTransitionOperationName = "OpenDetail"
    tool_settings.TargetIdSelector = "#target-id"
    tool_settings.ReturnToListOperationName = "ReturnToList"
    tool_settings.NextPageOperationName = "NextPage"
    tool_settings.NextPageAvailableSelector = "#next-page"
    tool_settings.ExistingRowMode = G_WEB_ROW_MODE_SKIP_EXISTING
    tool_settings.TimeoutSeconds = 0

    Dim operations As ObjectList
    Set operations = New_ObjectList("TransitionOperation")
    Call operations.Add(New_TransitionOperation("OpenList", "#open-list", WaitSelector:="#list-ready"))
    Call operations.Add(New_TransitionOperation("OpenDetail", "", ActionScript:="openDetail({{index}})", WaitSelector:="#target-id"))
    Call operations.Add(New_TransitionOperation("ReturnToList", "#return-list", WaitSelector:="#list-ready"))
    Call operations.Add(New_TransitionOperation("NextPage", "#next-link", WaitSelector:="#list-ready"))
    Set tool_settings.TransitionOperations = operations

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Set tool_settings.DetailColumnDefinitions = detail_defs

    Call pPrepareSingleExistingOkOutputRow(ws_stub, "T-001", 5)

    Dim create_body As String
    create_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""]}}}}"

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", create_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/url", "{""url"":""https://example.test/start""}")
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""auth-element""}}", "POST", "/session/abc/element", pCssFindBody("#top-ready"))
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""open-list-element""}}", "POST", "/session/abc/element", pCssFindBody("#open-list"))
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/element/open-list-element/click", "{}")
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""list-element""}}", "POST", "/session/abc/element", pCssFindBody("#list-ready"))
    Call client_double.Store.SetReturn("Execute.Sequence", "{""value"":[{""element-6066-11e4-a52e-4f735466cecf"":""row-page-1""}]}", "POST", "/session/abc/elements", pCssFindBody("#list tbody tr"), CLng(0))
    Call client_double.Store.SetReturn("Execute.Sequence", "{""value"":[{""element-6066-11e4-a52e-4f735466cecf"":""next-page""}]}", "POST", "/session/abc/elements", pCssFindBody("#next-page"), CLng(0))
    Call pSetTextElementSequence(client_double, "#list tbody tr:nth-child(1) td.id", "list-target", Array("T-001", "T-001", "T-001"))
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""next-link-element""}}", "POST", "/session/abc/element", pCssFindBody("#next-link"))
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/element/next-link-element/click", "{}")
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "DELETE", "/session/abc", "")

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    Dim process As WebDriverProcessTestDouble
    Set process = New WebDriverProcessTestDouble

    Set ProgStat = New ProgressStatus

    Dim lifecycle As WebDriverSessionLifecycle
    Set lifecycle = New_WebDriverSessionLifecycle(process, session_client, tool_settings)

    Dim runner As WebCollectionRunner
    Set runner = New_WebCollectionRunner(lifecycle, tool_settings)

    ' --- Act ---
    Call runner.Run

    ' --- Assert ---
    If Not Assert.ErrorRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.IsTrue 0 < InStr(1, Err.Description, "�y�[�W���i�݂܂���", vbTextCompare)
    Assert.EqualsNumeric 1, runner.SkippedCount
    Assert.EqualsNumeric 1, runner.PageCount
    Assert.EqualsNumeric 0, ProgStat.ProcessedValue
    Assert.IsFalse ProgStat.IsComplete
    Assert.Equals False, CBool(Application.StatusBar)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element/next-link-element/click", "{}")
    Assert.EqualsNumeric 1, process.Store.GetCallCount("StopProcess")
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "DELETE", "/session/abc", "")
End Sub

Private Sub pPrepareEmptyOutput(ByVal WsStub As WorksheetServiceTestDouble)
    Dim managed_search_bounds As WorksheetRangeBounds
    Set managed_search_bounds = New_RangeBounds(Row:=1, Column:=1, FinishRow:=G_ROW_MAX, FinishColumn:=4, Sheet:="output")

    Dim managed_used_bounds As WorksheetRangeBounds
    Set managed_used_bounds = New_RangeBounds(Row:=1, Column:=1, FinishRow:=0, FinishColumn:=0, Sheet:="output")
    Call WsStub.Store.SetReturn("GetUsedRangeBounds", managed_used_bounds, managed_search_bounds, True, True, True, False)

    Dim header_search_bounds As WorksheetRangeBounds
    Set header_search_bounds = New_RangeBounds(Row:=1, Column:=5, FinishRow:=1, FinishColumn:=G_COL_MAX, Sheet:="output")

    Dim header_used_bounds As WorksheetRangeBounds
    Set header_used_bounds = New_RangeBounds(Row:=1, Column:=5, FinishRow:=1, FinishColumn:=5, Sheet:="output")

    Dim header_values(1 To 1, 1 To 1) As Variant
    header_values(1, 1) = "����"

    Call WsStub.Store.SetReturn("GetUsedRangeBounds", header_used_bounds, header_search_bounds, True, True, True, False)
    Call WsStub.Store.SetReturn("ReadRange", header_values, header_used_bounds)
End Sub

Private Sub pPrepareExistingOutputRows(ByVal WsStub As WorksheetServiceTestDouble)
    Call pPrepareEmptyOutput(WsStub)

    Dim search_bounds As WorksheetRangeBounds
    Set search_bounds = New_RangeBounds(Row:=2, Column:=1, FinishRow:=G_ROW_MAX, FinishColumn:=1, Sheet:="output")

    Dim ok_rows As ObjectList
    Set ok_rows = New_ObjectList("WorksheetRangeBounds")
    Call ok_rows.Add(New_RangeBounds(Row:=5, Column:=1, Sheet:="output"))
    Call WsStub.Store.SetReturn("Find", ok_rows, "T-001", search_bounds, True, True, True, True)
    Call WsStub.Store.SetReturn("ReadCell", G_WEB_STATUS_OK, New_RangeBounds(Row:=5, Column:=2, Sheet:="output"), False)

    Dim error_rows As ObjectList
    Set error_rows = New_ObjectList("WorksheetRangeBounds")
    Call error_rows.Add(New_RangeBounds(Row:=6, Column:=1, Sheet:="output"))
    Call WsStub.Store.SetReturn("Find", error_rows, "T-002", search_bounds, True, True, True, True)
    Call WsStub.Store.SetReturn("ReadCell", G_WEB_STATUS_ERROR, New_RangeBounds(Row:=6, Column:=2, Sheet:="output"), False)
End Sub

Private Sub pPrepareExistingOkOutputRows(ByVal WsStub As WorksheetServiceTestDouble)
    Call pPrepareSingleExistingOkOutputRow(WsStub, "T-001", 5)
    Call pPrepareSingleExistingOkOutputRow(WsStub, "T-002", 6)
End Sub

Private Sub pPrepareSingleExistingOkOutputRow( _
        ByVal WsStub As WorksheetServiceTestDouble, _
        ByVal TargetId As String, _
        ByVal OutputRow As Long)

    Call pPrepareEmptyOutput(WsStub)

    Dim search_bounds As WorksheetRangeBounds
    Set search_bounds = New_RangeBounds(Row:=2, Column:=1, FinishRow:=G_ROW_MAX, FinishColumn:=1, Sheet:="output")

    Dim found_rows As ObjectList
    Set found_rows = New_ObjectList("WorksheetRangeBounds")
    Call found_rows.Add(New_RangeBounds(Row:=OutputRow, Column:=1, Sheet:="output"))
    Call WsStub.Store.SetReturn("Find", found_rows, TargetId, search_bounds, True, True, True, True)
    Call WsStub.Store.SetReturn("ReadCell", G_WEB_STATUS_OK, New_RangeBounds(Row:=OutputRow, Column:=2, Sheet:="output"), False)
End Sub

Private Function pCssFindBody(ByVal Selector As String) As String
    pCssFindBody = "{""using"":""css selector"",""value"":""" & Selector & """}"
End Function

Private Sub pSetTextElement( _
        ByVal ClientDouble As WebDriverClientTestDouble, _
        ByVal Selector As String, _
        ByVal ElementId As String, _
        ByVal ElementText As String)

    Call ClientDouble.Store.SetReturn( _
            "Execute", _
            "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""" & ElementId & """}}", _
            "POST", _
            "/session/abc/element", _
            pCssFindBody(Selector))
    Call ClientDouble.Store.SetReturn("Execute", "{""value"":""" & ElementText & """}", "GET", "/session/abc/element/" & ElementId & "/text", "")
End Sub

Private Sub pSetTextElementSequence( _
        ByVal ClientDouble As WebDriverClientTestDouble, _
        ByVal Selector As String, _
        ByVal ElementId As String, _
        ByVal ElementTexts As Variant)

    Call ClientDouble.Store.SetReturn( _
            "Execute", _
            "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""" & ElementId & """}}", _
            "POST", _
            "/session/abc/element", _
            pCssFindBody(Selector))

    Dim text_idx As Long
    For text_idx = LBound(ElementTexts) To UBound(ElementTexts)
        Call ClientDouble.Store.SetReturn("Execute.Sequence", "{""value"":""" & CStr(ElementTexts(text_idx)) & """}", "GET", "/session/abc/element/" & ElementId & "/text", "", CLng(text_idx))
    Next text_idx
End Sub

Private Sub pSetManagedHeadersBlank(ByVal WsStub As WorksheetServiceTestDouble, ByVal IsBlank As Boolean)
    Dim col_idx As Long
    For col_idx = 1 To 4
        Call WsStub.Store.SetReturn( _
                "IsEmptyCell", _
                IsBlank, _
                New_RangeBounds(Row:=1, Column:=col_idx, Sheet:="output"), _
                False)
    Next col_idx
End Sub

Private Sub pAssertWrittenCell( _
        ByVal Assert As UnitTestAssert, _
        ByVal WsStub As WorksheetServiceTestDouble, _
        ByVal RowIndex As Long, _
        ByVal ColumnIndex As Long, _
        ByVal ExpectedValue As String)

    Dim target_bounds As WorksheetRangeBounds
    Set target_bounds = New_RangeBounds(Row:=RowIndex, Column:=ColumnIndex, Sheet:="output")

    Assert.EqualsNumeric 1, WsStub.Store.GetCallCount("WriteCell", target_bounds), CaseName:="Row " & CStr(RowIndex) & ", Column " & CStr(ColumnIndex) & " call count"

    Dim call_record As TestDoubleCallRecord
    Set call_record = WsStub.Store.GetLatestCall("WriteCell", target_bounds)

    Assert.Equals ExpectedValue, CStr(call_record.GetArgument(1)), CaseName:="Row " & CStr(RowIndex) & ", Column " & CStr(ColumnIndex)
End Sub
