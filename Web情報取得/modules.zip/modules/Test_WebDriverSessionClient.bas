Attribute VB_Name = "Test_WebDriverSessionClient"
Option Explicit
Option Base 0

' #############################################################################
'!
'! @brief
'! WebDriver session client �̃��j�b�g �e�X�g�ł��B
'! Lib_UnitTest.UnitTestMain() �ɂ���Ď��s����܂��B
'!
' #############################################################################

Public Sub Test_WebDriverSessionClient_HeadlessTrue�ŕs���u���E�UCapabilities�����(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"

    Dim expected_body As String
    expected_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""]}}}}"

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", expected_body)

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    ' --- Act ---
    Dim actual_session_id As String
    actual_session_id = session_client.CreateSession()

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.Equals "abc", actual_session_id
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session", expected_body)
End Sub

Public Sub Test_WebDriverSessionClient_DownloadEnabledTrue�ňꎞ�_�E�����[�h�̈��Capabilities�ɓ����(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"
    tool_settings.DownloadEnabled = True

    Dim fs_stub As FileSystemServiceTestDouble
    Set fs_stub = New FileSystemServiceTestDouble
    Call fs_stub.Store.SetReturn("CreateTemporaryDirectory", "C:\Temp\xls-web-tools_tmp123.tmp", "xls-web-tools_")
    Set FsSrv = fs_stub

    Dim expected_body As String
    expected_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""],""prefs"":{""download.default_directory"":""C:\\Temp\\xls-web-tools_tmp123.tmp"",""download.prompt_for_download"":false,""download.directory_upgrade"":true}}}}}"

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", expected_body)

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    ' --- Act ---
    Dim actual_session_id As String
    actual_session_id = session_client.CreateSession()

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.Equals "abc", actual_session_id
    Assert.Equals "C:\Temp\xls-web-tools_tmp123.tmp", session_client.DownloadDirectoryPath
    Assert.EqualsNumeric 1, fs_stub.Store.GetCallCount("CreateTemporaryDirectory", "xls-web-tools_")
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session", expected_body)
End Sub


Public Sub Test_WebDriverSessionClient_QuitSession��WebDriverSession���I������(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"

    Dim create_body As String
    create_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""]}}}}"

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", create_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "DELETE", "/session/abc", "")

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    Dim session_id As String
    session_id = session_client.CreateSession()
    Err.Clear

    ' --- Act ---
    CallByName session_client, "QuitSession", VbMethod

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.Equals "abc", session_id
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "DELETE", "/session/abc", "")
End Sub

Public Sub Test_WebDriverSessionClient_NavigateToStartUrlSendsUrlCommand(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"
    tool_settings.StartUrl = "https://example.test/start"

    Dim create_body As String
    create_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""]}}}}"

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", create_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/url", "{""url"":""https://example.test/start""}")

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    Call session_client.CreateSession
    Err.Clear

    ' --- Act ---
    Call session_client.NavigateToStartUrl

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/url", "{""url"":""https://example.test/start""}")
End Sub

Public Sub Test_WebDriverSessionClient_WaitForSelector��Selector�o���𔻒肷��(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"

    Dim create_body As String
    create_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""]}}}}"

    Dim find_body As String
    find_body = "{""using"":""css selector"",""value"":""#top-ready""}"

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", create_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""element-1""}}", "POST", "/session/abc/element", find_body)

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    Call session_client.CreateSession
    Err.Clear

    ' --- Act ---
    Dim actual_element_id As String
    actual_element_id = session_client.WaitForSelector("#top-ready")

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.Equals "element-1", actual_element_id
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element", find_body)
End Sub

Public Sub Test_WebDriverSessionClient_WaitForSelector��Frame��Selector�o���𔻒肷��(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"

    Dim create_body As String
    create_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""]}}}}"

    Dim switch_top_body As String
    switch_top_body = "{""id"":null}"

    Dim frame_find_body As String
    frame_find_body = "{""using"":""css selector"",""value"":""iframe[name='right']""}"

    Dim switch_frame_body As String
    switch_frame_body = "{""id"":{""element-6066-11e4-a52e-4f735466cecf"":""frame-1""}}"

    Dim target_find_body As String
    target_find_body = "{""using"":""css selector"",""value"":""#list-ready""}"

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", create_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/frame", switch_top_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""frame-1""}}", "POST", "/session/abc/element", frame_find_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/frame", switch_frame_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""target-1""}}", "POST", "/session/abc/element", target_find_body)

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    Call session_client.CreateSession
    Err.Clear

    ' --- Act ---
    Dim actual_element_id As String
    actual_element_id = session_client.WaitForSelector("iframe[name='right'] >> #list-ready")

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.Equals "target-1", actual_element_id
    Assert.EqualsNumeric 2, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/frame", switch_top_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element", frame_find_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/frame", switch_frame_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element", target_find_body)
End Sub

Public Sub Test_WebDriverSessionClient_RunTransitionOperationChain�Ŋe������WaitSelector��ҋ@����(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"

    Dim create_body As String
    create_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""]}}}}"

    Dim open_other_body As String
    open_other_body = "{""using"":""css selector"",""value"":""#open-other""}"

    Dim other_ready_body As String
    other_ready_body = "{""using"":""css selector"",""value"":""#other-ready""}"

    Dim open_list_body As String
    open_list_body = "{""using"":""css selector"",""value"":""#open-list""}"

    Dim list_ready_body As String
    list_ready_body = "{""using"":""css selector"",""value"":""#list-ready""}"

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", create_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""open-other-1""}}", "POST", "/session/abc/element", open_other_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/element/open-other-1/click", "{}")
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""other-ready-1""}}", "POST", "/session/abc/element", other_ready_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""open-list-1""}}", "POST", "/session/abc/element", open_list_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/element/open-list-1/click", "{}")
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""list-ready-1""}}", "POST", "/session/abc/element", list_ready_body)

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    Dim operations As ObjectList
    Set operations = New_ObjectList("TransitionOperation")
    Call operations.Add(New_TransitionOperation("OpenOther", "#open-other", WaitSelector:="#other-ready"))
    Call operations.Add(New_TransitionOperation("OpenList", "#open-list", WaitSelector:="#list-ready"))

    Dim operation_chain As TransitionOperationChain
    Set operation_chain = New_TransitionOperationChain(operations)

    Call session_client.CreateSession
    Err.Clear

    ' --- Act ---
    Call session_client.RunTransitionOperationChain(operation_chain)

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element/open-other-1/click", "{}")
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element", other_ready_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element/open-list-1/click", "{}")
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element", list_ready_body)
End Sub

Public Sub Test_WebDriverSessionClient_RunTransitionOperation��Click��D�悷��(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"

    Dim create_body As String
    create_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""]}}}}"

    Dim find_body As String
    find_body = "{""using"":""css selector"",""value"":""#open-list""}"

    Dim script_body As String
    script_body = "{""script"":""openList()"",""args"":[]}"

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", create_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""element-1""}}", "POST", "/session/abc/element", find_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/element/element-1/click", "{}")
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/execute/sync", script_body)

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    Dim operation As TransitionOperation
    Set operation = New_TransitionOperation("OpenList", "#open-list", ActionScript:="openList()", WaitSelector:="#list-ready")

    Call session_client.CreateSession
    Err.Clear

    ' --- Act ---
    Call session_client.RunTransitionOperation(operation)

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element", find_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element/element-1/click", "{}")
    Assert.EqualsNumeric 0, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/execute/sync", script_body)
End Sub

Public Sub Test_WebDriverSessionClient_RunTransitionOperation��ActionInnerText��v�v�f��Click����(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"

    Dim create_body As String
    create_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""]}}}}"

    Dim elements_body As String
    elements_body = "{""using"":""css selector"",""value"":"".menu-button""}"

    Dim element_1_text_body As String
    element_1_text_body = pInnerTextScriptBody("element-1")

    Dim element_2_text_body As String
    element_2_text_body = pInnerTextScriptBody("element-2")

    Dim fallback_script_body As String
    fallback_script_body = "{""script"":""fallback()"",""args"":[]}"

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", create_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":[{""element-6066-11e4-a52e-4f735466cecf"":""element-1""},{""element-6066-11e4-a52e-4f735466cecf"":""element-2""}]}", "POST", "/session/abc/elements", elements_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":""�ΏۊO""}", "POST", "/session/abc/execute/sync", element_1_text_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":""�ꗗ\r\n��   �J��""}", "POST", "/session/abc/execute/sync", element_2_text_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/element/element-2/click", "{}")
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/execute/sync", fallback_script_body)

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    Dim operation As TransitionOperation
    Set operation = New_TransitionOperation("OpenList", ".menu-button", ActionInnerText:="�ꗗ �� �J��", ActionScript:="fallback()", WaitSelector:="#list-ready")

    Call session_client.CreateSession
    Err.Clear

    ' --- Act ---
    Call session_client.RunTransitionOperation(operation)

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/elements", elements_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/execute/sync", element_1_text_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/execute/sync", element_2_text_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element/element-2/click", "{}")
    Assert.EqualsNumeric 0, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/execute/sync", fallback_script_body)
End Sub

Public Sub Test_WebDriverSessionClient_RunTransitionOperation��ActionInnerText��v0���Ȃ�ScriptFallback���Ȃ�(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"

    Dim create_body As String
    create_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""]}}}}"

    Dim elements_body As String
    elements_body = "{""using"":""css selector"",""value"":"".menu-button""}"

    Dim element_1_text_body As String
    element_1_text_body = pInnerTextScriptBody("element-1")

    Dim element_2_text_body As String
    element_2_text_body = pInnerTextScriptBody("element-2")

    Dim fallback_script_body As String
    fallback_script_body = "{""script"":""fallback()"",""args"":[]}"

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", create_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":[{""element-6066-11e4-a52e-4f735466cecf"":""element-1""},{""element-6066-11e4-a52e-4f735466cecf"":""element-2""}]}", "POST", "/session/abc/elements", elements_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":""�ΏۊO""}", "POST", "/session/abc/execute/sync", element_1_text_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":""�ʍ���""}", "POST", "/session/abc/execute/sync", element_2_text_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/execute/sync", fallback_script_body)

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    Dim operation As TransitionOperation
    Set operation = New_TransitionOperation("OpenList", ".menu-button", ActionInnerText:="�ꗗ���J��", ActionScript:="fallback()", WaitSelector:="#list-ready")

    Call session_client.CreateSession
    Err.Clear

    ' --- Act ---
    Call session_client.RunTransitionOperation(operation)

    ' --- Assert ---
    Assert.ErrorRaised 0, Err.Number, Err.Source, Err.Description
    Assert.IsTrue 0 < InStr(1, Err.Description, "OperationName=OpenList", vbBinaryCompare)
    Assert.IsTrue 0 < InStr(1, Err.Description, "ActionSelector=.menu-button", vbBinaryCompare)
    Assert.IsTrue 0 < InStr(1, Err.Description, "ActionInnerText=�ꗗ���J��", vbBinaryCompare)
    Assert.IsTrue 0 < InStr(1, Err.Description, "MatchCount=0", vbBinaryCompare)
    Assert.EqualsNumeric 0, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/execute/sync", fallback_script_body)
End Sub

Public Sub Test_WebDriverSessionClient_RunTransitionOperation��ActionInnerText��v�������Ȃ�ScriptFallback���Ȃ�(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"

    Dim create_body As String
    create_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""]}}}}"

    Dim elements_body As String
    elements_body = "{""using"":""css selector"",""value"":"".menu-button""}"

    Dim element_1_text_body As String
    element_1_text_body = pInnerTextScriptBody("element-1")

    Dim element_2_text_body As String
    element_2_text_body = pInnerTextScriptBody("element-2")

    Dim fallback_script_body As String
    fallback_script_body = "{""script"":""fallback()"",""args"":[]}"

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", create_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":[{""element-6066-11e4-a52e-4f735466cecf"":""element-1""},{""element-6066-11e4-a52e-4f735466cecf"":""element-2""}]}", "POST", "/session/abc/elements", elements_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":""�ꗗ �� �J��""}", "POST", "/session/abc/execute/sync", element_1_text_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":""�ꗗ\n��    �J��""}", "POST", "/session/abc/execute/sync", element_2_text_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/execute/sync", fallback_script_body)

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    Dim operation As TransitionOperation
    Set operation = New_TransitionOperation("OpenList", ".menu-button", ActionInnerText:="�ꗗ �� �J��", ActionScript:="fallback()", WaitSelector:="#list-ready")

    Call session_client.CreateSession
    Err.Clear

    ' --- Act ---
    Call session_client.RunTransitionOperation(operation)

    ' --- Assert ---
    Assert.ErrorRaised 0, Err.Number, Err.Source, Err.Description
    Assert.IsTrue 0 < InStr(1, Err.Description, "MatchCount=2", vbBinaryCompare)
    Assert.EqualsNumeric 0, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/execute/sync", fallback_script_body)
End Sub

Public Sub Test_WebDriverSessionClient_RunTransitionOperation��ActionInnerText�͕��������ʂ���(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"

    Dim create_body As String
    create_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""]}}}}"

    Dim elements_body As String
    elements_body = "{""using"":""css selector"",""value"":"".menu-button""}"

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", create_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":[{""element-6066-11e4-a52e-4f735466cecf"":""element-1""},{""element-6066-11e4-a52e-4f735466cecf"":""element-2""},{""element-6066-11e4-a52e-4f735466cecf"":""element-3""}]}", "POST", "/session/abc/elements", elements_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":""ABC �A ��""}", "POST", "/session/abc/execute/sync", pInnerTextScriptBody("element-1"))
    Call client_double.Store.SetReturn("Execute", "{""value"":""abc � ��""}", "POST", "/session/abc/execute/sync", pInnerTextScriptBody("element-2"))
    Call client_double.Store.SetReturn("Execute", "{""value"":""abc �A �A""}", "POST", "/session/abc/execute/sync", pInnerTextScriptBody("element-3"))

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    Dim operation As TransitionOperation
    Set operation = New_TransitionOperation("OpenList", ".menu-button", ActionInnerText:="abc �A ��", WaitSelector:="#list-ready")

    Call session_client.CreateSession
    Err.Clear

    ' --- Act ---
    Call session_client.RunTransitionOperation(operation)

    ' --- Assert ---
    Assert.ErrorRaised 0, Err.Number, Err.Source, Err.Description
    Assert.IsTrue 0 < InStr(1, Err.Description, "MatchCount=0", vbBinaryCompare)
End Sub

Public Sub Test_WebDriverSessionClient_RunTransitionOperation��ActionInnerText�Ώۂ�Stale�Ȃ�ĒT������(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"

    Dim create_body As String
    create_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""]}}}}"

    Dim elements_body As String
    elements_body = "{""using"":""css selector"",""value"":"".menu-button""}"

    Dim old_text_body As String
    old_text_body = pInnerTextScriptBody("element-old")

    Dim new_text_body As String
    new_text_body = pInnerTextScriptBody("element-new")

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", create_body)
    Call client_double.Store.SetReturn("Execute.Sequence", "{""value"":[{""element-6066-11e4-a52e-4f735466cecf"":""element-old""}]}", "POST", "/session/abc/elements", elements_body, CLng(0))
    Call client_double.Store.SetReturn("Execute.Sequence", "{""value"":[{""element-6066-11e4-a52e-4f735466cecf"":""element-new""}]}", "POST", "/session/abc/elements", elements_body, CLng(1))
    Call client_double.Store.SetReturn("Execute", "{""value"":""�ꗗ���J��""}", "POST", "/session/abc/execute/sync", old_text_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":""�ꗗ���J��""}", "POST", "/session/abc/execute/sync", new_text_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":{""error"":""stale element reference"",""message"":""stale element reference""}}", "POST", "/session/abc/element/element-old/click", "{}")
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/element/element-new/click", "{}")

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    Dim operation As TransitionOperation
    Set operation = New_TransitionOperation("OpenList", ".menu-button", ActionInnerText:="�ꗗ���J��", WaitSelector:="#list-ready")

    Call session_client.CreateSession
    Err.Clear

    ' --- Act ---
    Call session_client.RunTransitionOperation(operation)

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.EqualsNumeric 2, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/elements", elements_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/execute/sync", old_text_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/execute/sync", new_text_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element/element-old/click", "{}")
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element/element-new/click", "{}")
End Sub

Public Sub Test_WebDriverSessionClient_RunTransitionOperation��Frame��ActionInnerText��v�v�f��Click����(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"

    Dim create_body As String
    create_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""]}}}}"

    Dim switch_top_body As String
    switch_top_body = "{""id"":null}"

    Dim frame_find_body As String
    frame_find_body = "{""using"":""css selector"",""value"":""iframe[name='right']""}"

    Dim switch_frame_body As String
    switch_frame_body = "{""id"":{""element-6066-11e4-a52e-4f735466cecf"":""frame-1""}}"

    Dim elements_body As String
    elements_body = "{""using"":""css selector"",""value"":"".menu-button""}"

    Dim element_1_text_body As String
    element_1_text_body = pInnerTextScriptBody("target-1")

    Dim element_2_text_body As String
    element_2_text_body = pInnerTextScriptBody("target-2")

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", create_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/frame", switch_top_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""frame-1""}}", "POST", "/session/abc/element", frame_find_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/frame", switch_frame_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":[{""element-6066-11e4-a52e-4f735466cecf"":""target-1""},{""element-6066-11e4-a52e-4f735466cecf"":""target-2""}]}", "POST", "/session/abc/elements", elements_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":""�ΏۊO""}", "POST", "/session/abc/execute/sync", element_1_text_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":""�ڍׂ��J��""}", "POST", "/session/abc/execute/sync", element_2_text_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/element/target-2/click", "{}")

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    Dim operation As TransitionOperation
    Set operation = New_TransitionOperation("OpenDetail", "iframe[name='right'] >> .menu-button", ActionInnerText:="�ڍׂ��J��", WaitSelector:="#target-id")

    Call session_client.CreateSession
    Err.Clear

    ' --- Act ---
    Call session_client.RunTransitionOperation(operation)

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/frame", switch_top_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element", frame_find_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/frame", switch_frame_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/elements", elements_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/execute/sync", element_1_text_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/execute/sync", element_2_text_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element/target-2/click", "{}")
End Sub

Public Sub Test_WebDriverSessionClient_RunTransitionOperation��ActionInnerText�m���Click���s�Ȃ�ScriptFallback����(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"

    Dim create_body As String
    create_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""]}}}}"

    Dim elements_body As String
    elements_body = "{""using"":""css selector"",""value"":"".menu-button""}"

    Dim element_text_body As String
    element_text_body = pInnerTextScriptBody("element-1")

    Dim fallback_script_body As String
    fallback_script_body = "{""script"":""fallback()"",""args"":[]}"

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", create_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":[{""element-6066-11e4-a52e-4f735466cecf"":""element-1""}]}", "POST", "/session/abc/elements", elements_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":""�ꗗ���J��""}", "POST", "/session/abc/execute/sync", element_text_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":{""error"":""element click intercepted"",""message"":""blocked""}}", "POST", "/session/abc/element/element-1/click", "{}")
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/execute/sync", fallback_script_body)

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    Dim operation As TransitionOperation
    Set operation = New_TransitionOperation("OpenList", ".menu-button", ActionInnerText:="�ꗗ���J��", ActionScript:="fallback()", WaitSelector:="#list-ready")

    Call session_client.CreateSession
    Err.Clear

    ' --- Act ---
    Call session_client.RunTransitionOperation(operation)

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/elements", elements_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element/element-1/click", "{}")
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/execute/sync", fallback_script_body)
End Sub

Public Sub Test_WebDriverSessionClient_RunTransitionOperation��Frame���v�f��Click����(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"

    Dim create_body As String
    create_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""]}}}}"

    Dim switch_top_body As String
    switch_top_body = "{""id"":null}"

    Dim frame_find_body As String
    frame_find_body = "{""using"":""css selector"",""value"":""iframe[name='right']""}"

    Dim switch_frame_body As String
    switch_frame_body = "{""id"":{""element-6066-11e4-a52e-4f735466cecf"":""frame-1""}}"

    Dim target_find_body As String
    target_find_body = "{""using"":""css selector"",""value"":""#list tbody tr:first-child td:nth-child(2)""}"

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", create_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/frame", switch_top_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""frame-1""}}", "POST", "/session/abc/element", frame_find_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/frame", switch_frame_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""target-1""}}", "POST", "/session/abc/element", target_find_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/element/target-1/click", "{}")

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    Dim operation As TransitionOperation
    Set operation = New_TransitionOperation("OpenList", "iframe[name='right'] >> #list tbody tr:first-child td:nth-child(2)", WaitSelector:="#list-ready")

    Call session_client.CreateSession
    Err.Clear

    ' --- Act ---
    Call session_client.RunTransitionOperation(operation)

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/frame", switch_top_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element", frame_find_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/frame", switch_frame_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element", target_find_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element/target-1/click", "{}")
End Sub

Public Sub Test_WebDriverSessionClient_RunTransitionOperation�Œʏ�Click�s�\�Ȃ�ScriptClick����(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"

    Dim create_body As String
    create_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""]}}}}"

    Dim find_body As String
    find_body = "{""using"":""css selector"",""value"":""#open-list""}"

    Dim script_click_body As String
    script_click_body = "{""script"":""arguments[0].click();"",""args"":[{""element-6066-11e4-a52e-4f735466cecf"":""element-1""}]}"

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", create_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""element-1""}}", "POST", "/session/abc/element", find_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":{""error"":""element not interactable"",""message"":""element not interactable""}}", "POST", "/session/abc/element/element-1/click", "{}")
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/execute/sync", script_click_body)

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    Dim operation As TransitionOperation
    Set operation = New_TransitionOperation("OpenList", "#open-list", WaitSelector:="#list-ready")

    Call session_client.CreateSession
    Err.Clear

    ' --- Act ---
    Call session_client.RunTransitionOperation(operation)

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element", find_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element/element-1/click", "{}")
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/execute/sync", script_click_body)
End Sub

Public Sub Test_WebDriverSessionClient_RunTransitionOperation��ScriptOnly�����s����(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"

    Dim create_body As String
    create_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""]}}}}"

    Dim script_body As String
    script_body = "{""script"":""openList()"",""args"":[]}"

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", create_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/execute/sync", script_body)

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    Dim operation As TransitionOperation
    Set operation = New_TransitionOperation("OpenList", "", ActionScript:="openList()", WaitSelector:="#list-ready")

    Call session_client.CreateSession
    Err.Clear

    ' --- Act ---
    Call session_client.RunTransitionOperation(operation)

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/execute/sync", script_body)
End Sub

Public Sub Test_WebDriverSessionClient_HeadlessFalse�ŉ��u���E�UCapabilities�����(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = False
    tool_settings.BrowserProfilePath = "D:\DedicatedProfile"

    Dim expected_body As String
    expected_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=D:\\DedicatedProfile""]}}}}"

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""visible""}}", "POST", "/session", expected_body)

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    ' --- Act ---
    Dim actual_session_id As String
    actual_session_id = session_client.CreateSession()

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.Equals "visible", actual_session_id
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session", expected_body)
End Sub

Public Sub Test_WebDriverSessionClient_ReadDetailColumnValues�Œ��o��ʂ��Ƃ̒l���ꊇ���o����(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"

    Dim create_body As String
    create_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""]}}}}"

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#subject", ExtractType:="TextContent"))
    Call detail_defs.Add(New_DetailColumnDefinition("�����N", "iframe[name='right'] >> #link", ExtractType:="Attribute", AttributeName:="href"))
    Call detail_defs.Add(New_DetailColumnDefinition("�S����", "#owner", ExtractType:="InnerText"))

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", create_body)
    Call client_double.Store.SetReturn("Execute.AnyRequestBody", "{""value"": [""�Č�A"", ""https://example.test/detail"", ""�R�c���Y""]}", "POST", "/session/abc/execute/sync")

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)
    Call session_client.CreateSession
    Err.Clear

    ' --- Act ---
    Dim actual_values As ArrayObject
    Set actual_values = session_client.ReadDetailColumnValues(detail_defs)

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.Equals "�Č�A", CStr(actual_values.Item(0))
    Assert.Equals "https://example.test/detail", CStr(actual_values.Item(1))
    Assert.Equals "�R�c���Y", CStr(actual_values.Item(2))
    Assert.EqualsNumeric 1, pCountExecuteCalls(client_double, "POST", "/session/abc/execute/sync")
End Sub

Public Sub Test_WebDriverSessionClient_CountElements��Frame���̈�v������Ԃ�(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"

    Dim create_body As String
    create_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""]}}}}"

    Dim switch_top_body As String
    switch_top_body = "{""id"":null}"

    Dim frame_find_body As String
    frame_find_body = "{""using"":""css selector"",""value"":""iframe[name='right']""}"

    Dim switch_frame_body As String
    switch_frame_body = "{""id"":{""element-6066-11e4-a52e-4f735466cecf"":""frame-1""}}"

    Dim list_item_find_body As String
    list_item_find_body = "{""using"":""css selector"",""value"":""#list tbody tr""}"

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""sessionId"":""abc""}}", "POST", "/session", create_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/frame", switch_top_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":{""element-6066-11e4-a52e-4f735466cecf"":""frame-1""}}", "POST", "/session/abc/element", frame_find_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":null}", "POST", "/session/abc/frame", switch_frame_body)
    Call client_double.Store.SetReturn("Execute", "{""value"":[{""element-6066-11e4-a52e-4f735466cecf"":""row-1""},{""element-6066-11e4-a52e-4f735466cecf"":""row-2""}]}", "POST", "/session/abc/elements", list_item_find_body)

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)
    Call session_client.CreateSession
    Err.Clear

    ' --- Act ---
    Dim actual_count As Long
    actual_count = session_client.CountElements("iframe[name='right'] >> #list tbody tr")

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.EqualsNumeric 2, actual_count
    Assert.EqualsNumeric 2, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/frame", switch_top_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/element", frame_find_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/frame", switch_frame_body)
    Assert.EqualsNumeric 1, client_double.Store.GetCallCount("Execute", "POST", "/session/abc/elements", list_item_find_body)
End Sub

Public Sub Test_WebDriverSessionClient_WebDriverErrorResponse�������t���ōđ��o����(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.Headless = True
    tool_settings.BrowserProfilePath = "C:\Profile"

    Dim create_body As String
    create_body = "{""capabilities"":{""alwaysMatch"":{""browserName"":""MicrosoftEdge"",""ms:edgeOptions"":{""args"":[""--user-data-dir=C:\\Profile"",""--headless=new""]}}}}"

    Dim client_double As WebDriverClientTestDouble
    Set client_double = New WebDriverClientTestDouble
    Call client_double.Store.SetReturn("Execute", "{""value"":{""error"":""session not created"",""message"":""profile locked""}}", "POST", "/session", create_body)

    Dim session_client As WebDriverSessionClient
    Set session_client = New_WebDriverSessionClient(client_double, tool_settings)

    ' --- Act ---
    Dim actual_session_id As String
    actual_session_id = session_client.CreateSession()

    ' --- Assert ---
    Assert.ErrorRaised 0, Err.Number, Err.Source, Err.Description
    Assert.IsTrue 0 < InStr(1, Err.Description, "session not created", vbTextCompare)
    Assert.IsTrue 0 < InStr(1, Err.Description, "profile locked", vbTextCompare)
End Sub

Private Function pInnerTextScriptBody(ByVal ElementId As String) As String
    pInnerTextScriptBody = "{""script"":""var value = arguments[0].innerText; return value === null || value === undefined ? '' : String(value);"",""args"":[{""element-6066-11e4-a52e-4f735466cecf"":""" & ElementId & """}]}"
End Function

Private Function pCountExecuteCalls( _
        ByVal ClientDouble As WebDriverClientTestDouble, _
        ByVal HttpMethod As String, _
        ByVal EndpointPath As String) As Long

    Dim result_count As Long
    result_count = 0

    Dim calls As ObjectList
    Set calls = ClientDouble.Store.GetCallsAll("Execute")

    Dim call_idx As Long
    For call_idx = 0 To calls.Count - 1
        Dim call_record As TestDoubleCallRecord
        Set call_record = calls.Item(call_idx)
        If CStr(call_record.GetArgument(0)) = HttpMethod And CStr(call_record.GetArgument(1)) = EndpointPath Then
            result_count = result_count + 1
        End If
    Next call_idx

    pCountExecuteCalls = result_count
End Function
