Attribute VB_Name = "Test_OutputConditionEvaluator"
Option Explicit
Option Base 0

Public Sub Test_OutputConditionEvaluator_ANDOR������]���ł���(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("�\����", "#requester"))
    Call detail_defs.Add(New_DetailColumnDefinition("�㗝�\����", "#proxy"))
    Call detail_defs.Add(New_DetailColumnDefinition("�����ςݓ�", "#processed"))

    Dim evaluator As OutputConditionEvaluator
    Set evaluator = New OutputConditionEvaluator
    Call evaluator.Initialize("([�\����] == ""�R�c"" OR [�㗝�\����] == ""�R�c"") AND [�����ςݓ�] != ""��""", detail_defs)

    Dim detail_values As ArrayObject
    Set detail_values = New ArrayObject
    Call detail_values.ReDimArray(0, 2)
    Call detail_values.Update(0, "")
    Call detail_values.Update(1, "�R�c")
    Call detail_values.Update(2, "")

    Dim actual As Boolean
    actual = evaluator.ShouldOutput(detail_values)

    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Call Assert.IsTrue(actual, "�����Ɉ�v����ڍגl�͏o�͑ΏۂɂȂ�")
End Sub

Public Sub Test_OutputConditionEvaluator_�����s��v��False��Ԃ�(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("�\����", "#requester"))

    Dim evaluator As OutputConditionEvaluator
    Set evaluator = New OutputConditionEvaluator
    Call evaluator.Initialize("[�\����] == ""�R�c""", detail_defs)

    Dim detail_values As ArrayObject
    Set detail_values = New ArrayObject
    Call detail_values.ReDimArray(0, 0)
    Call detail_values.Update(0, "����")

    Dim actual As Boolean
    actual = evaluator.ShouldOutput(detail_values)

    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Call Assert.IsFalse(actual, "�����Ɉ�v���Ȃ��ڍגl�͏o�͑ΏۊO�ɂȂ�")
End Sub

Public Sub Test_OutputConditionEvaluator_output���w��̒��o��������Q�Ƃł���(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#decision"))

    Dim evaluator As OutputConditionEvaluator
    Set evaluator = New OutputConditionEvaluator
    Call evaluator.Initialize("[����] == ""�Ώ�""", detail_defs)

    Dim detail_values As ArrayObject
    Set detail_values = New ArrayObject
    Call detail_values.ReDimArray(0, 0)
    Call detail_values.Update(0, "�Ώ�")

    Dim actual As Boolean
    actual = evaluator.ShouldOutput(detail_values)

    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Call Assert.IsTrue(actual, "output �w�b�_�[�ɂȂ����o��̏�����v�ŏo�͑ΏۂɂȂ�")
End Sub

Public Sub Test_OutputConditionEvaluator_����`��Q�Ƃ̓G���[(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("�\����", "#requester"))

    Dim evaluator As OutputConditionEvaluator
    Set evaluator = New OutputConditionEvaluator
    Call evaluator.Initialize("[����`] == ""�R�c""", detail_defs)

    If Not Assert.ErrorRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Call Assert.IsTrue(0 < InStr(1, Err.Description, "����`", vbTextCompare), "����`�� OutputColumnName ���G���[�����Ɋ܂܂��")
End Sub

Public Sub Test_OutputConditionEvaluator_OutputColumnName�d���̓G���[(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("�\����", "#requester"))
    Call detail_defs.Add(New_DetailColumnDefinition("�\����", "#requester2"))

    Dim evaluator As OutputConditionEvaluator
    Set evaluator = New OutputConditionEvaluator
    Call evaluator.Initialize("", detail_defs)

    If Not Assert.ErrorRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Call Assert.IsTrue(0 < InStr(1, Err.Description, "�d��", vbTextCompare), "�d������ OutputColumnName ���G���[�ɂȂ�")
End Sub

Public Sub Test_OutputConditionEvaluator_OutputColumnName�召�Ⴂ�͕ʗ�Ƃ��ĎQ�Ƃł���(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("Name", "#upper-name"))
    Call detail_defs.Add(New_DetailColumnDefinition("name", "#lower-name"))

    Dim evaluator As OutputConditionEvaluator
    Set evaluator = New OutputConditionEvaluator
    Call evaluator.Initialize("[Name] == ""UPPER"" AND [name] == ""LOWER""", detail_defs)

    Dim detail_values As ArrayObject
    Set detail_values = New ArrayObject
    Call detail_values.ReDimArray(0, 1)
    Call detail_values.Update(0, "UPPER")
    Call detail_values.Update(1, "LOWER")

    Dim actual As Boolean
    actual = evaluator.ShouldOutput(detail_values)

    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Call Assert.IsTrue(actual, "�啶�������������قȂ� OutputColumnName ��ʂ̒��o��Ƃ��ď����Q�Ƃł���")
End Sub

Public Sub Test_OutputConditionEvaluator_LF���܂�OutputColumnName����LF�ŎQ�Ƃł���(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    Dim column_name As String
    column_name = "����" & vbLf & "�ڍ�"

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition(column_name, "#subject"))

    Dim evaluator As OutputConditionEvaluator
    Set evaluator = New OutputConditionEvaluator
    Call evaluator.Initialize("[" & column_name & "] == ""�Ώ�""", detail_defs)

    Dim detail_values As ArrayObject
    Set detail_values = New ArrayObject
    Call detail_values.ReDimArray(0, 0)
    Call detail_values.Update(0, "�Ώ�")

    Dim actual As Boolean
    actual = evaluator.ShouldOutput(detail_values)

    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Call Assert.IsTrue(actual, "LF ���܂� OutputColumnName ���� LF �̗�Q�Ƃŏ����]���ł���")
End Sub

Public Sub Test_OutputConditionEvaluator_��Q�Ɠ�backslashn��LF�Ƃ��Ĉ���Ȃ�(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����" & vbLf & "�ڍ�", "#subject"))

    Dim evaluator As OutputConditionEvaluator
    Set evaluator = New OutputConditionEvaluator
    Call evaluator.Initialize("[����\n�ڍ�] == ""�Ώ�""", detail_defs)

    If Not Assert.ErrorRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Call Assert.IsTrue(0 < InStr(1, Err.Description, "����`", vbTextCompare), "��Q�Ɠ��� \n �͎� LF �ɕϊ�����Ȃ�")
End Sub

Public Sub Test_OutputConditionEvaluator_�����񃊃e������backslashn��LF�Ƃ��Ĉ���(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#subject"))

    Dim evaluator As OutputConditionEvaluator
    Set evaluator = New OutputConditionEvaluator
    Call evaluator.Initialize("[����] == ""A\nB""", detail_defs)

    Dim detail_values As ArrayObject
    Set detail_values = New ArrayObject
    Call detail_values.ReDimArray(0, 0)
    Call detail_values.Update(0, "A" & vbLf & "B")

    Dim actual As Boolean
    actual = evaluator.ShouldOutput(detail_values)

    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Call Assert.IsTrue(actual, "�����񃊃e�������� \n �� LF �Ƃ��Ĕ�r�����")
End Sub

Public Sub Test_OutputConditionEvaluator_LF�Ⴂ�͕ʗ�Ƃ��ĎQ�Ƃł���(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    Dim first_column_name As String
    first_column_name = "����" & vbLf & "A"

    Dim second_column_name As String
    second_column_name = "����" & vbLf & "B"

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition(first_column_name, "#decision-a"))
    Call detail_defs.Add(New_DetailColumnDefinition(second_column_name, "#decision-b"))

    Dim evaluator As OutputConditionEvaluator
    Set evaluator = New OutputConditionEvaluator
    Call evaluator.Initialize("[" & second_column_name & "] == ""�Ώ�""", detail_defs)

    Dim detail_values As ArrayObject
    Set detail_values = New ArrayObject
    Call detail_values.ReDimArray(0, 1)
    Call detail_values.Update(0, "�ΏۊO")
    Call detail_values.Update(1, "�Ώ�")

    Dim actual As Boolean
    actual = evaluator.ShouldOutput(detail_values)

    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Call Assert.IsTrue(actual, "LF �ňقȂ� OutputColumnName �͕ʗ�Ƃ��ď����Q�Ƃł���")
End Sub

Public Sub Test_OutputConditionEvaluator_�Œ�Ǘ��񖼂Ɠ����̒��o��������Q�Ƃł���(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition(G_WEB_OUTPUT_COL_TARGET_ID, "#detail-target-id"))

    Dim evaluator As OutputConditionEvaluator
    Set evaluator = New OutputConditionEvaluator
    Call evaluator.Initialize("[" & G_WEB_OUTPUT_COL_TARGET_ID & "] == ""DETAIL-001""", detail_defs)

    Dim detail_values As ArrayObject
    Set detail_values = New ArrayObject
    Call detail_values.ReDimArray(0, 0)
    Call detail_values.Update(0, "DETAIL-001")

    Dim actual As Boolean
    actual = evaluator.ShouldOutput(detail_values)

    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Call Assert.IsTrue(actual, "�Œ�Ǘ��񖼂Ɠ����̒��o�������������Q�Ƃ���")
End Sub

Public Sub Test_OutputConditionEvaluator_�����񃊃e�����̃G�X�P�[�v�����߂���(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#subject"))

    Dim evaluator As OutputConditionEvaluator
    Set evaluator = New OutputConditionEvaluator

    Dim expression_text As String
    expression_text = "[����] == " & Chr$(34) & "A\" & Chr$(34) & "B\nC" & Chr$(34)
    Call evaluator.Initialize(expression_text, detail_defs)

    Dim detail_values As ArrayObject
    Set detail_values = New ArrayObject
    Call detail_values.ReDimArray(0, 0)
    Call detail_values.Update(0, "A" & Chr$(34) & "B" & vbLf & "C")

    Dim actual As Boolean
    actual = evaluator.ShouldOutput(detail_values)

    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Call Assert.IsTrue(actual, "�G�X�P�[�v�����񂪕]�������")
End Sub

Public Sub Test_OutputConditionEvaluator_���e�����̑O��󔒂��������Ĕ�r����(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("�\����", "#requester"))

    Dim evaluator As OutputConditionEvaluator
    Set evaluator = New OutputConditionEvaluator
    Call evaluator.Initialize("[�\����] == "" �R�c """, detail_defs)

    Dim detail_values As ArrayObject
    Set detail_values = New ArrayObject
    Call detail_values.ReDimArray(0, 0)
    Call detail_values.Update(0, "�R�c")

    Dim actual As Boolean
    actual = evaluator.ShouldOutput(detail_values)

    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Call Assert.IsTrue(actual, "���e�����̑O��󔒂͔�r�O�ɏ��������")
End Sub

Public Sub Test_OutputConditionEvaluator_���mescape�̓G���[(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#subject"))

    Dim evaluator As OutputConditionEvaluator
    Set evaluator = New OutputConditionEvaluator

    Dim expression_text As String
    expression_text = "[����] == " & Chr$(34) & "A\q" & Chr$(34)
    Call evaluator.Initialize(expression_text, detail_defs)

    If Not Assert.ErrorRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Call Assert.IsTrue(0 < InStr(1, Err.Description, "���m", vbTextCompare), "���m escape ���G���[�����Ɋ܂܂��")
End Sub

Public Sub Test_OutputConditionEvaluator_�����Q�Ɨ�͔C�ӗ�Ƃ��ēǂݎ��(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#decision", IsRequired:=True, BlankMode:="ErrorIfBlank"))

    Dim evaluator As OutputConditionEvaluator
    Set evaluator = New OutputConditionEvaluator
    Call evaluator.Initialize("[����] == """"", detail_defs)

    Dim referenced_defs As ObjectList
    Set referenced_defs = evaluator.ReferencedColumnDefinitions

    Dim referenced_def As DetailColumnDefinition
    Set referenced_def = referenced_defs.Item(0)

    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.EqualsNumeric 1, referenced_defs.Count
    Assert.Equals "����", referenced_def.OutputColumnName
    Call Assert.IsFalse(referenced_def.IsRequired, "�����Q�Ɨ�� selector �������󕶎��񈵂��ł���悤�C�ӗ�Ƃ��ēǂ�")
    Assert.Equals "AllowBlank", referenced_def.BlankMode
End Sub

Public Sub Test_OutputConditionEvaluator_�h����������Q�Ɨ�Ƃ��ĕԂ�(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#source"))
    Call detail_defs.Add(New_DetailColumnDefinition("�h��", "", ValueExpression:="[����]"))

    Dim evaluator As OutputConditionEvaluator
    Set evaluator = New OutputConditionEvaluator
    Call evaluator.Initialize("[�h��] == ""�Ώ�""", detail_defs)

    Dim referenced_defs As ObjectList
    Set referenced_defs = evaluator.ReferencedColumnDefinitions

    Dim referenced_def As DetailColumnDefinition
    Set referenced_def = referenced_defs.Item(0)

    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Assert.EqualsNumeric 1, referenced_defs.Count
    Assert.Equals "�h��", referenced_def.OutputColumnName
    Assert.IsTrue referenced_def.IsDerived
    Assert.Equals "[����]", referenced_def.ValueExpression
    Assert.Equals "AllowBlank", referenced_def.BlankMode
End Sub
