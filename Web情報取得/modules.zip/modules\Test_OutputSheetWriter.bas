Attribute VB_Name = "Test_OutputSheetWriter"
Option Explicit
Option Base 0

' #############################################################################
'!
'! @brief
'! OutputSheetWriter �̃��j�b�g �e�X�g�ł��B
'! Lib_UnitTest.UnitTestMain() �ɂ���Ď��s����܂��B
'!
' #############################################################################

Public Sub Test_OutputSheetWriter_�Œ�Ǘ���Əڍח�̃w�b�_�[��p�ӂ���(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim wb_stub As WorkbookServiceTestDouble
    Set wb_stub = New WorkbookServiceTestDouble
    Set WbSrv = wb_stub

    Dim ws_stub As WorksheetServiceTestDouble
    Set ws_stub = New WorksheetServiceTestDouble
    Set WsSrv = ws_stub

    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.OutputSheetName = "result"

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#title", OutputEnabled:=True))
    Call detail_defs.Add(New_DetailColumnDefinition("�\����", "#requester"))
    Set tool_settings.DetailColumnDefinitions = detail_defs

    Dim writer As OutputSheetWriter
    Set writer = New_OutputSheetWriter(tool_settings)

    ' --- Act ---
    Call writer.EnsureHeaders

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Call pAssertHeader(Assert, ws_stub, 1, G_WEB_OUTPUT_COL_TARGET_ID)
    Call pAssertHeader(Assert, ws_stub, 2, G_WEB_OUTPUT_COL_STATUS)
    Call pAssertHeader(Assert, ws_stub, 3, G_WEB_OUTPUT_COL_ERROR)
    Call pAssertHeader(Assert, ws_stub, 4, G_WEB_OUTPUT_COL_DOWNLOAD_STATUS)
    Call pAssertHeader(Assert, ws_stub, 5, "����")
    Assert.EqualsNumeric 0, ws_stub.Store.GetCallCount("WriteCell", New_RangeBounds(Row:=1, Column:=6, Sheet:="result"))
End Sub

Public Sub Test_OutputSheetWriter_�f�f�o�͂͑Ώ�ID��v�s���㏑������(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim wb_stub As WorkbookServiceTestDouble
    Set wb_stub = New WorkbookServiceTestDouble
    Set WbSrv = wb_stub

    Dim ws_stub As WorksheetServiceTestDouble
    Set ws_stub = New WorksheetServiceTestDouble
    Set WsSrv = ws_stub

    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.OutputSheetName = "result"

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#title", OutputEnabled:=True))
    Set tool_settings.DetailColumnDefinitions = detail_defs

    Dim search_bounds As WorksheetRangeBounds
    Set search_bounds = New_RangeBounds(Row:=2, Column:=1, FinishRow:=G_ROW_MAX, FinishColumn:=1, Sheet:="result")

    Dim found_rows As ObjectList
    Set found_rows = New_ObjectList("WorksheetRangeBounds")
    Call found_rows.Add(New_RangeBounds(Row:=5, Column:=1, Sheet:="result"))
    Call ws_stub.Store.SetReturn("Find", found_rows, "T-001", search_bounds, True, True, True, True)

    Dim detail_values As ArrayObject
    Set detail_values = New ArrayObject
    Call detail_values.ReDimArray(0, 0)
    Call detail_values.Update(0, "�Č�A")

    Dim writer As OutputSheetWriter
    Set writer = New_OutputSheetWriter(tool_settings)

    ' --- Act ---
    Call writer.WriteDiagnosticRow("T-001", G_WEB_STATUS_OK, "", detail_values, G_WEB_DOWNLOAD_STATUS_NO_FILE)

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Call pAssertWrittenCell(Assert, ws_stub, 5, 1, "T-001")
    Call pAssertWrittenCell(Assert, ws_stub, 5, 2, G_WEB_STATUS_OK)
    Call pAssertWrittenCell(Assert, ws_stub, 5, 4, G_WEB_DOWNLOAD_STATUS_NO_FILE)
    Call pAssertWrittenCell(Assert, ws_stub, 5, 5, "�Č�A")
    Assert.EqualsNumeric 0, ws_stub.Store.GetCallCount("WriteCell", New_RangeBounds(Row:=2, Column:=1, Sheet:="result"))
End Sub

Public Sub Test_OutputSheetWriter_�����s�����𔻒肷��(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble

    Dim writer As OutputSheetWriter
    Set writer = New_OutputSheetWriter(tool_settings)

    ' --- Act & Assert ---
    tool_settings.ExistingRowMode = G_WEB_ROW_MODE_SKIP_EXISTING
    Assert.IsFalse writer.ShouldWriteExistingRow(G_WEB_STATUS_OK)
    Assert.IsTrue writer.ShouldWriteExistingRow(G_WEB_STATUS_ERROR)
    Assert.IsTrue writer.ShouldWriteExistingRow(G_WEB_STATUS_OK, IsDiagnosticMode:=True)

    Call writer.ShouldWriteExistingRow("UNKNOWN")
    Assert.ErrorRaised 0, Err.Number, Err.Source, Err.Description
    Assert.Equals "�����s�̎擾��Ԃ��s���ł��B(UNKNOWN)", Err.Description
    Err.Clear

    tool_settings.ExistingRowMode = G_WEB_ROW_MODE_OVERWRITE
    Assert.IsTrue writer.ShouldWriteExistingRow(G_WEB_STATUS_OK)
    Assert.IsTrue writer.ShouldWriteExistingRow(G_WEB_STATUS_ERROR)

    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
End Sub

Public Sub Test_OutputSheetWriter_�{�Ԏ��W�Ώ۔���͑Ώ�ID��L�[��ExistingRowMode�ɏ]��(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim wb_stub As WorkbookServiceTestDouble
    Set wb_stub = New WorkbookServiceTestDouble
    Set WbSrv = wb_stub

    Dim ws_stub As WorksheetServiceTestDouble
    Set ws_stub = New WorksheetServiceTestDouble
    Set WsSrv = ws_stub

    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.OutputSheetName = "result"

    Dim search_bounds As WorksheetRangeBounds
    Set search_bounds = New_RangeBounds(Row:=2, Column:=1, FinishRow:=G_ROW_MAX, FinishColumn:=1, Sheet:="result")

    Dim ok_rows As ObjectList
    Set ok_rows = New_ObjectList("WorksheetRangeBounds")
    Call ok_rows.Add(New_RangeBounds(Row:=5, Column:=1, Sheet:="result"))
    Call ws_stub.Store.SetReturn("Find", ok_rows, "T-OK", search_bounds, True, True, True, True)
    Call ws_stub.Store.SetReturn("ReadCell", G_WEB_STATUS_OK, New_RangeBounds(Row:=5, Column:=2, Sheet:="result"), False)

    Dim error_rows As ObjectList
    Set error_rows = New_ObjectList("WorksheetRangeBounds")
    Call error_rows.Add(New_RangeBounds(Row:=6, Column:=1, Sheet:="result"))
    Call ws_stub.Store.SetReturn("Find", error_rows, "T-ERROR", search_bounds, True, True, True, True)
    Call ws_stub.Store.SetReturn("ReadCell", G_WEB_STATUS_ERROR, New_RangeBounds(Row:=6, Column:=2, Sheet:="result"), False)

    Dim missing_rows As ObjectList
    Set missing_rows = New_ObjectList("WorksheetRangeBounds")
    Call ws_stub.Store.SetReturn("Find", missing_rows, "T-NEW", search_bounds, True, True, True, True)

    Dim writer As OutputSheetWriter
    Set writer = New_OutputSheetWriter(tool_settings)

    ' --- Act & Assert ---
    tool_settings.ExistingRowMode = G_WEB_ROW_MODE_SKIP_EXISTING
    Assert.IsFalse writer.ShouldCollectTarget("T-OK")
    Assert.IsTrue writer.ShouldCollectTarget("T-ERROR")
    Assert.IsTrue writer.ShouldCollectTarget("T-NEW")

    tool_settings.ExistingRowMode = G_WEB_ROW_MODE_OVERWRITE
    Assert.IsTrue writer.ShouldCollectTarget("T-OK")
    Assert.IsTrue writer.ShouldCollectTarget("T-ERROR")
    Assert.IsTrue writer.ShouldCollectTarget("T-NEW")

    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
End Sub

Public Sub Test_OutputSheetWriter_�{�ԏo�͂͑Ώ�ID��v�s���X�V�����o�^�Ȃ疖���֒ǉ�����(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim wb_stub As WorkbookServiceTestDouble
    Set wb_stub = New WorkbookServiceTestDouble
    Set WbSrv = wb_stub

    Dim ws_stub As WorksheetServiceTestDouble
    Set ws_stub = New WorksheetServiceTestDouble
    Set WsSrv = ws_stub

    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.OutputSheetName = "result"

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#title", OutputEnabled:=True))
    Set tool_settings.DetailColumnDefinitions = detail_defs

    Dim search_bounds As WorksheetRangeBounds
    Set search_bounds = New_RangeBounds(Row:=2, Column:=1, FinishRow:=G_ROW_MAX, FinishColumn:=1, Sheet:="result")

    Dim existing_rows As ObjectList
    Set existing_rows = New_ObjectList("WorksheetRangeBounds")
    Call existing_rows.Add(New_RangeBounds(Row:=5, Column:=1, Sheet:="result"))
    Call ws_stub.Store.SetReturn("Find", existing_rows, "T-001", search_bounds, True, True, True, True)

    Dim missing_rows As ObjectList
    Set missing_rows = New_ObjectList("WorksheetRangeBounds")
    Call ws_stub.Store.SetReturn("Find", missing_rows, "T-002", search_bounds, True, True, True, True)

    Dim used_search_bounds As WorksheetRangeBounds
    Set used_search_bounds = New_RangeBounds(Row:=1, Column:=1, FinishRow:=G_ROW_MAX, FinishColumn:=5, Sheet:="result")

    Dim used_bounds As WorksheetRangeBounds
    Set used_bounds = New_RangeBounds(Row:=1, Column:=1, FinishRow:=6, FinishColumn:=5, Sheet:="result")
    Call ws_stub.Store.SetReturn("GetUsedRangeBounds", used_bounds, used_search_bounds, True, True, True, False)

    Dim detail_values As ArrayObject
    Set detail_values = New ArrayObject
    Call detail_values.ReDimArray(0, 0)
    Call detail_values.Update(0, "�Č�A")

    Dim writer As OutputSheetWriter
    Set writer = New_OutputSheetWriter(tool_settings)

    ' --- Act ---
    Call writer.WriteCollectionRow("T-001", G_WEB_STATUS_OK, "", detail_values, G_WEB_DOWNLOAD_STATUS_DOWNLOADED)
    Call writer.WriteCollectionRow("T-002", G_WEB_STATUS_ERROR, "missing", detail_values, G_WEB_DOWNLOAD_STATUS_ERROR)

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Call pAssertWrittenCell(Assert, ws_stub, 5, 1, "T-001")
    Call pAssertWrittenCell(Assert, ws_stub, 5, 2, G_WEB_STATUS_OK)
    Call pAssertWrittenCell(Assert, ws_stub, 5, 4, G_WEB_DOWNLOAD_STATUS_DOWNLOADED)
    Call pAssertWrittenCell(Assert, ws_stub, 5, 5, "�Č�A")
    Call pAssertWrittenCell(Assert, ws_stub, 7, 1, "T-002")
    Call pAssertWrittenCell(Assert, ws_stub, 7, 2, G_WEB_STATUS_ERROR)
    Call pAssertWrittenCell(Assert, ws_stub, 7, 3, "missing")
    Call pAssertWrittenCell(Assert, ws_stub, 7, 4, G_WEB_DOWNLOAD_STATUS_ERROR)
    Call pAssertWrittenCell(Assert, ws_stub, 7, 5, "�Č�A")
End Sub

Public Sub Test_OutputSheetWriter_�S�ڍח��o�͂Ȃ�Œ�Ǘ��񂾂�����������(ByVal Assert As UnitTestAssert)
    On Error Resume Next

    ' --- Arrange ---
    Dim wb_stub As WorkbookServiceTestDouble
    Set wb_stub = New WorkbookServiceTestDouble
    Set WbSrv = wb_stub

    Dim ws_stub As WorksheetServiceTestDouble
    Set ws_stub = New WorksheetServiceTestDouble
    Set WsSrv = ws_stub

    Dim tool_settings As ToolSettingsTestDouble
    Set tool_settings = New ToolSettingsTestDouble
    tool_settings.OutputSheetName = "result"

    Dim detail_defs As ObjectList
    Set detail_defs = New_ObjectList("DetailColumnDefinition")
    Call detail_defs.Add(New_DetailColumnDefinition("����", "#title"))
    Call detail_defs.Add(New_DetailColumnDefinition("�\����", "#requester"))
    Set tool_settings.DetailColumnDefinitions = detail_defs

    Dim search_bounds As WorksheetRangeBounds
    Set search_bounds = New_RangeBounds(Row:=2, Column:=1, FinishRow:=G_ROW_MAX, FinishColumn:=1, Sheet:="result")

    Dim missing_rows As ObjectList
    Set missing_rows = New_ObjectList("WorksheetRangeBounds")
    Call ws_stub.Store.SetReturn("Find", missing_rows, "T-001", search_bounds, True, True, True, True)

    Dim used_search_bounds As WorksheetRangeBounds
    Set used_search_bounds = New_RangeBounds(Row:=1, Column:=1, FinishRow:=G_ROW_MAX, FinishColumn:=4, Sheet:="result")

    Dim used_bounds As WorksheetRangeBounds
    Set used_bounds = New_RangeBounds(Row:=1, Column:=1, FinishRow:=1, FinishColumn:=4, Sheet:="result")
    Call ws_stub.Store.SetReturn("GetUsedRangeBounds", used_bounds, used_search_bounds, True, True, True, False)

    Dim detail_values As ArrayObject
    Set detail_values = New ArrayObject
    Call detail_values.ReDimArray(0, 1)
    Call detail_values.Update(0, "�Č�A")
    Call detail_values.Update(1, "�R�c���Y")

    Dim writer As OutputSheetWriter
    Set writer = New_OutputSheetWriter(tool_settings)

    ' --- Act ---
    Call writer.WriteCollectionRow("T-001", G_WEB_STATUS_OK, "", detail_values, G_WEB_DOWNLOAD_STATUS_NO_FILE)

    ' --- Assert ---
    If Not Assert.ErrorNotRaised(0, Err.Number, Err.Source, Err.Description) Then Exit Sub
    Call pAssertWrittenCell(Assert, ws_stub, 2, 1, "T-001")
    Call pAssertWrittenCell(Assert, ws_stub, 2, 2, G_WEB_STATUS_OK)
    Call pAssertWrittenCell(Assert, ws_stub, 2, 3, "")
    Call pAssertWrittenCell(Assert, ws_stub, 2, 4, G_WEB_DOWNLOAD_STATUS_NO_FILE)
    Assert.EqualsNumeric 0, ws_stub.Store.GetCallCount("WriteCell", New_RangeBounds(Row:=2, Column:=5, Sheet:="result"))
End Sub

Private Sub pAssertHeader(ByVal Assert As UnitTestAssert, ByVal WsStub As WorksheetServiceTestDouble, ByVal ColumnIndex As Long, ByVal ExpectedHeader As String)
    Dim target_bounds As WorksheetRangeBounds
    Set target_bounds = New_RangeBounds(Row:=1, Column:=ColumnIndex, Sheet:="result")

    Dim call_record As TestDoubleCallRecord
    Set call_record = WsStub.Store.GetLatestCall("WriteCell", target_bounds)

    Assert.Equals ExpectedHeader, CStr(call_record.GetArgument(1)), CaseName:="Column " & CStr(ColumnIndex)
End Sub

Private Sub pAssertWrittenCell( _
        ByVal Assert As UnitTestAssert, _
        ByVal WsStub As WorksheetServiceTestDouble, _
        ByVal RowIndex As Long, _
        ByVal ColumnIndex As Long, _
        ByVal ExpectedValue As String)

    Dim target_bounds As WorksheetRangeBounds
    Set target_bounds = New_RangeBounds(Row:=RowIndex, Column:=ColumnIndex, Sheet:="result")

    Assert.EqualsNumeric 1, WsStub.Store.GetCallCount("WriteCell", target_bounds), CaseName:="Row " & CStr(RowIndex) & ", Column " & CStr(ColumnIndex) & " call count"

    Dim call_record As TestDoubleCallRecord
    Set call_record = WsStub.Store.GetLatestCall("WriteCell", target_bounds)

    Assert.Equals ExpectedValue, CStr(call_record.GetArgument(1)), CaseName:="Row " & CStr(RowIndex) & ", Column " & CStr(ColumnIndex)
End Sub
